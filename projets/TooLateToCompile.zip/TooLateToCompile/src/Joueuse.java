class Joueuse {
    int indiceSave;
    String nom; 
    int score;
    String progression; // la progression est les initiales des nodes validés, par exemple C(ontroleur), C(orle) I(UT) CCI 
    int multiplicateur;
}