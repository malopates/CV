class Question{
    String question;    
    String reponse1;
    String reponse2;
    String reponse3;
    String reponse4;
    int idxReponse;
    int idxQuestion;
//    CSVFILE type;
}