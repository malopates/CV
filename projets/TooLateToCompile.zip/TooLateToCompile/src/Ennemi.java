import extensions.CSVFile;
import extensions.File;

class Ennemi extends Program {
    String nom;
    int affinite;
    int idxDialogue;
    String nomJauge;
    int tauxJauge;
    CSVFile dialogue;
    CSVFile questions;
    File sprite;
    int longueurSprite;
    String description;

}