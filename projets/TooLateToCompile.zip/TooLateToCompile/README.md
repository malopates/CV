Too Late Too Compile 
===========

Développé par ALVAREZ Malori & CHEN Eva
Contacts : malori.alvarez.etu@univ-lille.fr, eva.chen.etu@univ-lille.fr

# Présentation de Too Late To Compile
Vous vous levez en retard pour votre présentation de SAE 1.02 ! Vous hâtant dans le métro, tout le monde semble tester vos connaissances dans diverses matières relatives à vos études... Si vous n'arrivez pas à répondre, vous n'arriverez certainement pas à l'heure !

Des captures d'écran illustrant le fonctionnement du logiciel sont proposées dans le répertoire shots.


# Utilisation de Too Late To Compile

Afin d'utiliser le projet, il suffit de taper les commandes suivantes dans un terminal :

```
./compile.sh
```
Permet la compilation des fichiers présents dans 'src' et création des fichiers '.class' dans 'classes'

```
./run.sh
```
Permet le lancement du jeu
