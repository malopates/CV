# SAE 3.03 Déploiement d'une application - Sujet 3


## 1. Accès à un service HTTP (NGINX)

Nous devons installer le serveur web NGINX sur la machine virtuelle , qu'on réinstallera différement par la suite

```
user@matrix$ sudo apt install nginx
```
(Vérifier que celui-ci est démarré à l’aide de la commande ```systemctl```)

Puis le client HTTP
```
user@matrix$ sudo apt install curl
```

On accède ensuite à notre serveur nginx, qui nous présente sa page par défaut
```
user@vm$ curl http://localhost
```

## 2. Accès depuis la machine physique
On souhaiterait pouvoir accéder au service qui s’exécute sur la machine virtuelle depuis la machine physique. 

Mais pour le moment, on ne peut pas accéder depuis la machine physique au service qui s'exécute sur la machine virtuelle,la machine virtuelle se trouvant sur un réseau privé.

Pour y pallier, nous allons nous servir de la fonction tunnel de SSH.


On peut lire dans les pages du man **ssh(1)** les options possibles, mais aussi modifier .ssh/config afin que notre URL  ```http://machine-physique.iutinfo.fr:9090``` par défaut, nous servant pour le NGINX de la machine virtuelle.

Au plus simple, la commande est la suivante : 
```
login@phys$ ssh -L 9090:localhost:80 vmjump
 ```

Autrement, via ~/.ssh/config
L'on ajoute cette configuration sur la machine physique (correspondant à vmjump) :
```
Host vmjump
    ...
    LocalForward 9090 127.0.0.1 80
```
 
**Synapse** est le serveur matrix dont on se servira, pour l'installer, rien de plus simple.
```
user@matrix$ sudo apt install -y lsb-release wget apt-transport-https
user@matrix$ sudo wget -O /usr/share/keyrings/matrix-org-archive-keyring.gpg https://packages.matrix.org/debian/matrix-org-archive-keyring.gpg
user@matrix$ echo "deb [signed-by=/usr/share/keyrings/matrix-org-archive-keyring.gpg] https://packages.matrix.org/debian/ $(lsb_release -cs) main" | sudo tee /etc/apt/sources.list.d/matrix-org.list
user@matrix$ sudo apt update
user@matrix$ sudo apt install matrix-synapse-py3
```
> Pendant l'installation, il sera demandé un nom de serveur, qui sera dans notre cas ```machine-physique.iutinfo.fr:8008```

Les logs (historique des actions) se trouveront dans ```/var/log/matrix-synapse/homeserver.log```
Afin de s'assurer que le service est lancé, l'on peut refaire un systemctl 
```user@matrix$ sudo systemctl status matrix-synapse```

## 2.2 Accès à distance  

Le fichier de configuration sera ```/etc/matrix-synapse/homeserver.yaml```
Pour écouter également sur l'interface du réseau privé, modifier la section ``bind_addresses`` (avec votre numéro de réseau à la place des x évidemment)
```bind_addresses: ['::1', '127.0.0.1', '10.42.xx.1']```

## 3. Paramétrage spécifique pour une instance dans un réseau privé
Le serveur n’est pas accessible depuis internet, on voudrait qu’il le soit. 
Les paramètres par défaut de Synapse considèrent donc que le serveur est accessible de l’extérieur et qu’il ne cherche pas à contacter des éléments situés sur un réseau privé.
> On ne veut pas que notre serveur contacte d’autres serveurs pour obtenir des clés publiques de signatures. L'on désactivera les serveurs de clés de confiance (pour éviter les communications externes) et affectera donc la variable de configuration ```trusted_key_servers``` à ```[]```

## 4. Utilisation d'une base PostgreSQL
Lors de la semaine précédente, nous avons créé une base de données matrix avec les options de création par défaut. Ces options ne conviennent pas à Synapse et il refusera de démarrer si vous ne changez rien à votre base de données.
Si nécessaire, nettoyez l'ancienne base, reconnectez-vous et drop tout :
```
user@matrix$ sudo su - postgres
postgres@matrix$ dropdb matrix
postgres@matrix$ dropuser matrix
```

Puis l'on recrée un-e utilisateur-ice (avec les bonnes options) et une base et l'on quitte postgres : 
```
postgres@matrix$ createuser --pwprompt matrix
# → Mot de passe conseillé : matrix
postgres@matrix$ createdb --encoding=UTF8 --locale=C --template=template0 --owner=matrix matrix
```
```
postgres@matrix$ exit
```


## 5. Configuration de Synapse pour utiliser PostgreSQL

Remplacez la section database dans /etc/matrix-synapse/homeserver.yaml par :
```
database:
  name: psycopg2
  args:
    user: matrix
    password: matrix
    dbname: matrix
    host: localhost
    cp_min: 5
    cp_max: 10
```

Et l'on crée nos utilisateur-ices en ajoutant une clé partagée dans notre serveur (```homeserver.yaml```), puis redémarre
```
registration_shared_secret: "clé-au-pif"
```
```
user@matrix$ sudo systemctl restart matrix-synapse
```
```
user@matrix$ sudo register_new_matrix_user -c /etc/matrix-synapse/homeserver.yaml http://localhost:8008
```
> Suivre les instructions pour chaque utilisateur-ices

## 6. Connexion au serveur Matrix

L'on remodifie le tunnel SSH dans ~/.ssh/config (sur la machine physique) avec notre client web (```http://machine.iutinfo.fr:9090```)
Depuis lequel on créera un salon avec un-e utilisateur-ice et invitera l'autre
```
LocalForward 9090 127.0.0.1:8008
```

## 7. Activation de l’enregistrement des utilisateur-ices
Pour l’instant, notre serveur n’accepte pas les nouveaux utilisateur-ices.
De retour dans ```homeserver.yaml``` ajouter :

```
enable_registration: true
enable_registration_without_verification: true
```

Puis redémarrer Synapse et tester la création de comptes directement depuis Element.

## Note sur le chiffrement

Pour l’instant, tant que la connexion vers synapse est effectuée en HTTP (et non en HTTPS), la fédération d’instance est impossible. Il ne sera donc pas possible d’accéder à des canaux d’un serveur synapse avec un compte créé sur un autre serveur synapse.

De même, element vous indiquera une erreur à la récupération/création de clé, vous pouvez l’ignorer tant que la connexion ne sera pas faite en HTTPS.

## Changement de machine physique

Durant la SAÉ, vous devrez probablement changer de machine physique une ou plusieurs fois.

À l’installation de Synapse, vous avez renseigné le nom du serveur comme étant http://phys.iutinfo.fr:8008. Comme vous l’avez peut-être constaté, Synapse vous a indiqué que ce nom ne pouvait pas être changé à l’avenir sans avoir à recréer complètement la base de données (et donc perdre les données liées à Synapse).

Dans un déploiement classique, ce n’est pas vraiment un soucis car cette URL n’est pas censée changer. Or, dans notre déploiement, cette URL correspond à la machine physique que vous utilisez au moment de l’installation de Synapse. Si vous changez de machine physique au cours de la SAÉ, votre serveur synapse ne sera plus accessible par la même URL (car la redirection SSH permettant l’accès au service hébergé sur la VM aura changé).

Synapse se sert de cette information dans les identifiants des utilisateurs et des salons de discussion.

Si vous changez de machine physique vous devrez donc:

    arrêter Synapse
    modifier le fichier /etc/matrix-synapse/conf.d/server_name.yml pour mettre la nouvelle URL
    détruire et recréer la base de donnée
    recréer les utilisateurs
    redémarrer Synapse

Pour faciliter cela, voici un script de réinitialisation rapide (à exécuter en root sur la VM) :

```
#!/bin/bash

NEW_SERVER="nouvelle-machine.iutinfo.fr"

# 1. Mise à jour server_name
echo "server_name: \"$NEW_SERVER:8008\"" | sudo tee /etc/matrix-synapse/conf.d/server_name.yaml

# 2. Recréation base de données
su - postgres <<EOF
dropdb -f matrix
createdb --encoding=UTF8 --locale=C --template=template0 --owner=matrix matrix
EOF

# 3. Redémarrage
sudo systemctl restart matrix-synapse

# 4. A vous de refaire les users :)

# ne pas oublier pas de mettre à jour LocalForward dans ~/.ssh/config sur la nouvelle machine physique"
```

\newpage
