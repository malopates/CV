---
title: "Procédures Matrix"
author: "Couraudon, Alvarez, Poumaere"
date: "2026-01-12"
geometry: margin=2.5cm
fontsize: 11pt
mainfont: "DejaVu Serif"
colorlinks: true
linkcolor: blue
urlcolor: green
secnumdepth: 2
header-includes:
  - \usepackage{xcolor}
  - \usepackage{sectsty}
  - \sectionfont{\color{blue}}
  - \subsectionfont{\color{teal}}
  - \subsubsectionfont{\color{orange}}
---





# SAE 3.03 Déploiement d'une application - Sujet 1

### Réalisé par :
- Lucas Couraudon
- Malori Alvarez
- Mathieu Poumaere

## Vocabulaire de base

- **Machine physique** : Il s'agit de la machine qui est devant vous, celle sur laquelle vous êtes connecté en salle TP.
- **Machine de virtualisation** : Il s'agit de la machine qui fera fonctionner vos machines virtuelles. Vous vous y connecterez à distance depuis votre machine physique. C'est un serveur dédié qui se situe dans la salle serveur du département.
- **Machine virtuelle** : C'est une machine “émulée” par un logiciel de virtualisation. Elles seront accessibles via la machine de virtualisation.
- **Réseau physique** : Il s’agit du réseau des salles de TP. Les machines physiques et de virtualisation y sont connectées directement via une de leur interface réseau (**eth0** pour les salles de TP, **ens10f0** pour le serveur) ;
- **Réseau virtuel principal** : C'est un réseau virtuel, reliant la machine de virtualisation aux machines virtuelles s’y exécutant. Sur la machine de virtualisation, ce réseau correspond à l’interface **lxcbr0**.

## Ou executer mes commandes ?

Si nécessaire, le prompt indiquera également précisément l’utilisateur et la machine sur laquelle la commande doit s’exécuter sous la forme <span style="color:#f58319;background-color:#f59d199c;border-radius:2px;">*utilisateur@machine*</span>. Concernant la machine, il s’agira soit:
- de <span style="color:#9e0d0d;background-color:#fc6d6dab;border-radius:2px;">phys</span> pour représenter la machine physique.
- de <span style="color:#9e0d0d;background-color:#fc6d6dab;border-radius:2px;">virtu</span> pour représenter la machine de virtualisation.
- de <span style="color:#9e0d0d;background-color:#fc6d6dab;border-radius:2px;">vm</span> pour représenter la machine virtuelle dans les cas où il n’y aurait pas d’ambiguïté.
- d’un nom de machine virtuelle s’il est nécessaire de le préciser.

Dans le cas du nom d’utilisateur, le seul cas particulier sera <span style="color:#9e0d0d;background-color:#fc6d6dab;border-radius:2px;">login</span>. Ce cas se produira pour les commandes à saisir sur la machine physique ou la machine de virtualisation et il voudra simplement dire que vous devez exécuter la commande en utilisant votre compte étudiant.

Par exemple, si la commande `ls` est à exécuter sur la machine physique:

login@phys$ ls

Si la commande `id` est à exécuter en tant que l’utilisateur <span style="color:#f58319;background-color:#f59d199c;border-radius:2px;">root</span> de la machine virtuelle nommée <span style="color:#043e80;background-color:#5db7f3b9;border-radius:2px;">matrix</span>:

root@matrix# id

La convention <span style="color:#f58319;background-color:#f59d199c;border-radius:2px;"> *utilisateur@machine*</span> pourra également être utilisée pour désigner les paramètres de connexion de la commande `SSH`. Les mêmes noms particuliers s’appliqueront.


## Premiers pas
1. Pour réaliser cette SAE, nous avons besoin d'une **Machine de Virtualisation**, nous utiliserons dattier. il est possible de s'y connecter depuis les machines TP avec la commande suivante (sur <span style="color:#f58319;background-color:#f59d199c;border-radius:2px;">login@phys$</span>).

       ssh dattier.iutinfo.fr

S'il s'agit de votre première connexion, il faut vérifier le retour (l'empreinte de la clé) avant de valider. 

<a>![Retours valides](res/img/RetourSSH.png)</a>

Maintenant que la connexion est enregistré on peut se connecter avec la même commande puis note mot de passe.

2. Pour éviter de renter son mot de passe à chaque connexion il est possible d'utiliser une paire de clés SSH. Voici quelques liens si vous souhaitez plus d'informations sur les clés ssh <a href="https://www.sectigo.com/fr/blog/qu-est-ce-qu-une-cle-ssh"> Qu'est ce qu'une clé SSH </a> et <a href="https://www.youtube.com/watch?v=7iyACl9eCTU"> Fonctionnement des paires de clés SSH </a>

    a. Cette étape est optionnelle si vous avez déjà une paire de clés. Pour générer une paire de clés SSH, on utilisera la commande `login@phys$ ssh-keygen`. Lors de l'utilisation, vous devrez choisir un fichier destination (on peut garder celui par défaut.) et un mot de passe qui servira notamment à chiffrer ce fichier, il est conseillé d'utiliser un mot de passe robuste afin d'éviter qu'une personne récupérant ce fichier ne puisse utiliser la clé. 
    
    b. Pour vérifier que votre paire de clés est bien généré vous pouvez la récupérer dans le fichier `$HOME/.ssh/id_rsa.pub` à l'aide de la commande `cat`, vous devriez avoir un résultat du type `[options] type-clé clé commentaire`.
    
    c. Pour transmettre la clé SSH au serveur il suffit d'utiliser la commande ci-dessous, l'option `-i fichier` permet de donner le fichier dans lequel se trouve la clé. 
    
       ssh-copy-id -i $HOME/.ssh/id_rsa.pub dattier.iutinfo.fr

<span>*Note: la première fois que vous vous connecterez après avoir lié la clé au serveur vous devrez entrer votre mot de passe pour vérifier qu'il s'agit bien de votre clé*</span>


## Création et gestion des machines virtuelles 

Afin de créer la VM, utiliser la commande en <span style="color:#f58319;background-color:#f59d199c;border-radius:2px;"> *utilisateur@dattier$*</span>.

    vmiut creer matrix

        
le résultat doit être similaire a celui donné ci-dessous et vous devriez voir une machine nommé matrix en utilisant la commande `<span style="color:#1c6e03;background-color:#58ec2b8f;border-radius:2px;">`vmiut lister`. Si ce n'est pas le cas il peut que vous ne soyez pas sur la machine de virtualisation ou que les fichiers de votre machine virtuelle ont été effacés.

        Virtual machine 'matrix' is created and registered.
        UUID: 903447fe-d6ca-4f2f-9272-3f465a026540
        Settings file: '/usr/local/virtual_machine/infoetu/login/matrix/matrix.vbox'
        0%...10%...20%...30%...40%...50%...60%...70%...80%...90%...100%
        Clone medium created in format 'VMDK'. UUID: 99d2712d-e40d-4661-995f-b1147131414b
        # Paramètres vmiut
        MACHINE=matrix
        VBOXES=/usr/local/virtual_machine/infoetu/login
        RESEAU=vboxtap0
        MEMOIRE=1024
        VRDEPORT=5000-5050
        MODELE=/home/public/vm/disque-5Go-bullseye.vdi

        # Paramètres VirtualBox
        name=matrix
        UUID=903447fe-d6ca-4f2f-9272-3f465a026540
        path=/usr/local/virtual_machine/infoetu/login/matrix
        memory=1024
        etat=poweroff
        vrdeport=-1
        mac=08:00:27:ba:9a:8d

Après sa création, vous pouvez lancer matrix avec la première commande, l'arreter avec la deuxième et le supprimer avec la dernière.

    vmiut demarrer matrix
    vmiut arreter matrix
    vmiut supprimer matrix

Une fois que matrix est lancé vous pouvez voir les ip-potentiels avec `vmiut info [machine]` dans ce cas il faut évidement remplacé machine par matrix. Dans les informations qui seront affichées, la dernière ligne dois être : `ip-possible=` ou `ip-possible=10.42.xx.yy`. Dans le premier cas, la VM est démarrée mais n’a pas encore obtenu d’adresse IP, il suffit d'attendre un peu avant de relancer la commande et d'obtenir une ligne similaire au second cas (xx et yy seront remplacés par des nombres).


<span>*Note:<br>
Comme vous pouvez le constater, votre machine virtuelle a obtenu une adresse IP dans le réseau 10.42.0.0/16. Il s’agit du réseau virtuel principal. Dans ce réseau, on a:*</span>
<table>
        <tr><th>Machine</th> 	<th>Adresse</th></tr>
        <tr><td>Machine de virtualisation </td><td> 	10.42.0.1 </td></tr>
        <tr><td>Routeur, DNS </td><td>	10.42.0.1 </td></tr>
        <tr><td>Adresses dynamiques (attribuées automatiquement) </td><td>	10.42.1.0-10.42.99.255 </td></tr>
</table>

*La machine virtuelle a été créée à partir d’un modèle. Voici les caractéristiques du modèle:<br>
    <li>Distribution: Debian GNU/Linux 12 (bookworm)</li>
    <li>Utilisateur standard: user, mot de passe: user</li>
    <li>Administrateur: root, mot de passe: root</li>
    <li>empreinte des clés du serveur SSH du modèle :</li>*

    SHA256:FghmLiSpQ6iUxtlctLQIL7IvJVh5jVR2V4KWzuA5iuc (ED25519)
    SHA256:i78/YMok3edmxcXE6bCoOhp8DvOcidmIKzwZoq4ZN+E (RSA)
    SHA256:D/ASNXOlOemCp4SF9MDVrjNU+aQnxTF2zKTwzm24og4 (ECDSA)



### Utilisation des VM:

Pour utiliser vos machines virtuelles, il y a deux solutions, la première c'est d'utiliser une console virtuelle, elle permet de simuler un clavier et un écran qui serait connectés physiquement à la machine virtuelle. La seconde est de se connecter en SSH.

1.  Avec une console virtuelle

      On commencera par utiliser la commande `vmiut console matrix`. Comme la console virtuelle est une application graphique mais que vous êtes connectés à distance sur la machine de virtualisation, vous aurez un message d’erreur qui doit ressembler a **ERROR: Failed to open display:**. Pour palier à ce problème, on utilisera une fonctionnalité de SSH qui permet de rediriger une application graphique. 
      
      Pour cela, déconnectez vous de la machine de virtualisation et reconnectez vous avec la commande suivante `ssh -X dattier.iutinfo.fr` (l’option -X permet d’effectuer la redirection graphique.).

      Afin de vérifier les paramètres de réseau, connectez vous en tant que root et utilisez les commandes `ip addr show` et `ip route show`. Voici les paramètres minimum à vérifier, il y a 2 connexion, celle local **lo** et celle pour le serveur via **enp0s3** et la connexion avec enp0s3 se fait bien avec des adresses en 10.42.xx.yy.

2. Avec une connexion SSH

      Afin, de se connecter en SSH on utilisera la commande suivante, il faudra remplacer xx.yy par l'adresse obtenue précédement avec `vmiut info`.


        $ ssh user@10.42.xx.yy

3. Modifier la configuration réseau

    La machine virtuelle sera un serveur et elle hébergera un service. Il est donc préférable qu’elle ait toujours la même adresse IP. Pour cela, allez chercher l'adresse mise à disposition par l'IUT (<a href="https://moodle.univ-lille.fr/pluginfile.php/2793265/mod_resource/content/6/attribution-ips.html"> voir mon adresse</a>). Dans ce fichier, la plage sera indiquée sous la forme 10.42.xx.1-254. 

    Il faut réaliser les modifications suivantes dans le fichier **`/etc/network/interfaces`**

        auto enp0s3
        iface enp0s3 inet static
                address 10.42.X.1
                netmask 255.255.255.0
                gateway 10.42.0.1


    Ensuite, dans `/etc/resolv.conf`, il faut changer: 

        nameserver 10.42.X.1



    Enfin, coupez puis réactivez l'interface réseau enp0s3 et vérifiez que la nouvelle configuration réseau est persistante après un redémarrage : (ATTENTION!!! il faut exécuter les commandes en étant root et à partir de la console et non du SSH, sinon il n'y aurait plus de connexion et donc plus de shell distant).

        root@vm# ifdown enp0s3
        root@vm# ifup enp0s3
        root@vm# reboot



##  Configuration et mise à jour de la machine virtuelle

###  Connexion root et SSH

Pour se connecter en SSH, vous utiliserez la commande suivante, ATTENTION à **NE SURTOUT PAS** l'executer en tant que root une erreur `Permission Denied` sera déclanché, en effet, par défaut ssh ne permet pas les connexions en root. Il faut être en user et executer la commande `su` pour récupérer les privilèges nécessaires.
 
    login@virtu$ ssh root@10.42.X.1


------

## Accès aux VM depuis l'exterieur

**Rappel :**<br>
Comme vu précédement, la machine virtuelle est connectée au réseau virtuel principal. Ce dernier est spécifique à la machine de virtualisation et est privé. De ce fait, seules la machine de virtualisation et les machines virtuelles peuvent y accéder. Pour accéder a l'exterieur de ce réseaux il faut passer par le routeur 10.42.0.1, Pour faire simple on peut se le représenter comme une box internet. 


###  Mise à jour

Afin de mettre à jour la VM, (*note*: il est conseillé de le faire régulièrement), on lancera la commande suivante :

    root@vm# apt update && apt full-upgrade 


### Installer des outils

Afin d'installer des applications supplémentaires, il est possible d'utiliser APT(Advanced Packaging Tool), le gestionnaire de paquets en ligne de commande. Ce dernier est simple à prendre en main et efficace voici la base :
  
    root@vm# apt-get install ...



## Partie bonus

Pour créer différents alias et permettre la connexion direct entre la VM et la machine physique, vous devez modifier le fichier `@phys$ .ssh/config`.


Sur la machine de virtualisation, vous effectuerez les opérations suivantes.

    ssh-keygen
    ssh-copy-id user@10.42.X.1

Puis

    Host vm
        Hostname 10.42.X.1
        User user


Ensuite, vous permettrez à la machine physique de se connecter directement à la VM en utilisant une ligne SSH. Nous allons utiliser le transfert d'agent qui est une autre fonctionnalité offerte par SSH.

    Host virtu
    Hostname dattier.iutinfo.fr
    User login
    ForwardAgent yes

    Host vm
    Hostname 10.42.X.1
    User user
    ProxyJump virtu

*note : à ajouter dans le fichier`@phys$HOME/.ssh/config`*
\newpage
