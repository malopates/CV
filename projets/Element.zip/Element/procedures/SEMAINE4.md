# SAÉ 3.03 Déploiement d'une application - Sujet 4

## Element Web

Pour installer notre propre serveur pour exécuter le client matrix, nous avons le choix entre utiliser **nginx** ou **Apache**. Comparons les deux pour faire un choix : 

|   NGINX   |   APACHE   |
| :---------:|:-----------:|
| <span style="color:green">architecture asynchrone et non bloquante (gèrer plusieurs connexions dans un seul procesus)</span> | <span style="color:red">architecture orientée processus (un seul thread)</span> |
| <span style="color:green">met en cache les fichiers statiques (plus rapide)</span> | <span style="color:red"> performances statiques dépendent des MPMs </span> |
| <span style="color:red"> pas capable de traiter du contenu dynamique </span> | <span style="color:green"> exécute le contenu dynamique au sein du serveur web </span> |
| <span style="color:green"> multifonctionnel, plus performant pour des requêtes statiques </span> | <span style="color:green"> adapté aux environnements d'hébergement mutualisé, peut consommer beaucoup de mémoire du serveur </span> |

> Source : https://www.hostinger.fr/tutoriels/apache-vs-nginx 

Après nos recherches, nous avons décidé d'utiliser **nginx**.

### Installer **nginx** et le configurer de façon à ce que l’application Element soit accessible sur le port 8080 sur la machine virtuelle.

### Installation de NGINX

*Les commandes suivantes sont à faire en `root` sauf si précisé autrement*

On commence par mettre à jour les paquets :

        apt update
        apt upgrade

Puis on installe NGINX via APT :

        apt install nginx

> Si NGINX n'est pas affiché comme démarré, on utilise : `systemctl start nginx`

### Configuration

Afin d'avoir accès au serveur web sur le port **8080 de la machine physique**, il faut modifier la configuration SSH de la machine physique et y ajouter :  
        
        LocalForward 8080 127.0.0.1:8080

Cela permet de rediriger le port 8080 de la **machine virtuelle** à celui de la **machine physique**.

On doit donc apporter des modifications **dans la VM** : 

1. Dans `/etc/nginx/sites-enabled/default` : pour écouter le bon port, on change les `80` en `8080`.

1. On vérifie que la syntaxe est correcte avec `nginx -t`.

1. On redémarre nginx avec `systemctl restart nginx` pour que les modifications soient prises en compte.

1. On reboot la VM avec `reboot`.

**=> On peut maintenant accéder à la page d'accueil de nginx sur le port 8080 de la machine physique.**

##  Reverse proxy pour Synapse

Plusieurs logiciels permettent de faire un Reverse Proxy : 
- Squid
- Olfeo (payant)
- UCOPIA (payant)
- Nginx

Après réflexion, nous choisissons nginx de nouveau car nous nous sentons plus à l'aise de continuer à l'utiliser.


### Création machine virtuelle "rproxy"

Tout d'abord il faut créer dans la machine de virtualisation une nouvelle machine : 

    vmiut creer rproxy


Nous avons déjà fait les étapes de configuration réseau et d'accès SSH qui suivent, il suffit cette fois de les appliquer à notre machine. Il faut donc modifier l'adresse `10.42.xxx.1` par `10.42.xxx.2` et `matrix` par `rproxy`.

### Installation NGINX et configuration en reverse proxy

### Installation de NGINX

*Les commandes suivantes sont à faire en `root@rproxy#` sauf si précisé autrement*

On commence par mettre à jour les paquets :

        apt update
        apt upgrade

Puis on installe NGINX via APT :

        apt install nginx

> Si NGINX n'est pas affiché comme démarré, on utilise : `systemctl start nginx`

### Configuration en reverse proxy

Dans le fichier `etc/nginx/sites-enabled/default`, on modifie la partie "location" : 

        proxy_pass http://10.42.xxx.1:8008;

On redémarre nginx avec `systemctl restart nginx`. 

Dans la **machine physique**, on modifie `.ssh/config` : 
1. On retire la ligne `LocalForward <machine physique>.iutinfo.fr:9090 127.0.0.1:8008` de la partie `vmjump` 
1. On l'ajoute dans la partie de configuration de `rproxy` en remplaçant le port `8008` par le `80`.

=> Ici, le proxy gère la redirection de port et permet d'accèder à la page d'accueil de Synapse depuis la **machine physique** à l'adresse `<machine>.iutinfo.fr:9090` (c'est le **serveur** matrix qui est accessible)


