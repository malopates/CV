# SAE 3.03 Déploiement d'une application - Sujet 2

## 1. Changement du nom de la machine
Pour modifier le nom de la machine en matrix, éditez le fichier /etc/hostname :
```
root@matrix# echo "matrix" > /etc/hostname
```
(Pour plus d'informations, consultez la page du manuel : root@matrix# man hostname)

> Il faut modifier le fichier ```/etc/hosts``` afin que la commande suivante fonctionne : ```user@matrix$ ping matrix```

En ouvrant donc le fichier 
```
root@matrix# nano /etc/hosts
```
Et en ajoutant la ligne 
```127.0.0.1   matrix```

(En soit, l'adresse peut être n'importe laquelle tant qu'elle commence par 127 (adresses loopback), sauf 127.0.0.0 et 127.255.255.255.)

Puis redémarrer la machine pour effectuer les changements
```
root@matrix# reboot
```

## 2. Installation et configuration de la commande sudo

Pour installer le paquet sudo :
```
root@matrix# apt update
root@matrix# apt install sudo
```
Puis donner ces droits à user :
```
root@matrix# usermod -aG sudo user
```
*(```-aG``` sert à ajouter au groupe sans supprimer les groupes qui existent déjà.)*

## 3. Installation et configuration basique d’un serveur de base de données

On peut désormais passer au user (avec la commande ```su - user```)

Et installer PostgreSQL
```
user@matrix$ sudo apt update
user@matrix$ sudo apt install postgresql
```

Vérifiez que le service est bien démarré :

```
user@matrix$ sudo systemctl status postgresql
```

## 4. Création de l’utilisateur-ice et de la base de données

Maintenant, connectez-vous en tant que l’utilisateur-ice postgres
```
user@matrix$ sudo su - postgres
```
et créez l'utilisateur-ice PostgreSQL avec un mot de passe avec la commande ``createuser -P matrix`` (l'option ```-P``` demande un mot de passe, on définit par défaut matrix)

Et maintenant créez la base de donnée matrix appartenant à matrix (l'utilisateur-ice)
``` 
postgres@matrix$ createdb -O matrix matrix 
```
*(option -O indique le propriétaire de la base)*

Maintenant, revenir à l’utilisateur précédent :
```
postgres@matrix$ exit
```
puis tester la connexion depuis l’utilisateur user :
```
user@matrix$ psql -h localhost -U matrix -d matrix
```

pour quitter ```\q```.

\newpage
