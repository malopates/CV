package extensionPOO;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

import main.*;
import main.enums.Criterion;


public class AdolescentPlus extends Adolescent{
    
    private AdolescentPlus presetPaired;
    private ArrayList<AdolescentPlus> forbiddenFromPaired;
    // HashMap<String,Double> valuePerCriterion;
    //private static double[][] matrixPoids = ImportExportPlus.importPoidsFromCSV();
    private static HashMap<String,Double> weightPerCriterion=ImportExport.importWeightValues();

    public AdolescentPlus(String lastname, String forename, String gender, String BIRTHDATE, String BIRTHCOUNTRY, HashMap<Criterion, String> criteria){
        super(lastname, forename, gender, BIRTHDATE, BIRTHCOUNTRY, criteria);
        this.presetPaired=null;
        this.forbiddenFromPaired=new ArrayList<>();
        // this.valuePerCriterion = new HashMap<>();
        // this.weightPerCriterion =ImportExport.importWeightValues(); 
    }

    public static void fetchNewWeights(){
        AdolescentPlus.weightPerCriterion=ImportExport.importWeightValues();
    }

    public void addForbidden(AdolescentPlus ado){
        if(!this.forbiddenFromPaired.contains(ado)){
            this.forbiddenFromPaired.add(ado);
        }
    }
    public void removeForbidden(AdolescentPlus ado){
        this.forbiddenFromPaired.remove(ado);
    }
    public ArrayList<AdolescentPlus> getForbiddenFromPaired() {
        return forbiddenFromPaired;
    }

    public void setPresetPaired(AdolescentPlus presetPaired) {
        this.presetPaired = presetPaired;
    }
    public AdolescentPlus getPresetPaired() {
        return presetPaired;
    }
    public void removePreset(){
        this.presetPaired=null;
    }

    public static AdolescentPlus convertIntoAdolescentPlus(Adolescent ado){
        AdolescentPlus a=new AdolescentPlus(ado.getLastname(), ado.getForename(), ado.getGender(), ado.getBIRTHDATE(), ado.getBIRTHCOUNTRY(), ado.getCriteria());
        return a;
    }

    public static ArrayList<AdolescentPlus> expandAdolescents(ArrayList<Adolescent> ados){
        ArrayList<AdolescentPlus> res=new ArrayList<>();
        for(Adolescent ado: ados){
            // AdolescentPlus a=new AdolescentPlus(ado.getLastname(), ado.getForename(), ado.getGender(), ado.getBIRTHDATE(), ado.getBIRTHCOUNTRY(), ado.getCriteria());
            AdolescentPlus a=AdolescentPlus.convertIntoAdolescentPlus(ado);
            res.add(a);
        }
        return res;
    }
    
    public HashMap<String, Double> compatibilityScore(AdolescentPlus host) {
        //double res = super.compatibilityScore(host);
        
        double res=ToolBox.poidsCritères[0][0];
        
        double[][] matriceCout=ToolBox.poidsCritères;
    //     if((this.isCoherent())&&(host.isCoherent())){ 
    //         this.valuePerCriterion.put("GENDER", this.genderCriteria(matriceCout[1],host));            
    //         this.valuePerCriterion.put("AGE", this.ageCriteria(matriceCout[2], host));
    //         this.valuePerCriterion.put("HOBBIES", this.hobbyCriteria(matriceCout[3], host));
    //         this.valuePerCriterion.put("ANIMAL", this.animalCriteria(host));
    //         this.valuePerCriterion.put("FOOD", this.foodCriteria(host));
    //         this.valuePerCriterion.put("HISTORY", this.historyCriteria(host));

    //     }else{
    //         this.valuePerCriterion.put("GENDER", (ToolBox.poidsCritères[0][1])*100);
    //         this.valuePerCriterion.put("AGE", (ToolBox.poidsCritères[0][1])*100);
    //         this.valuePerCriterion.put("HOBBIES", (ToolBox.poidsCritères[0][1])*100);
    //         this.valuePerCriterion.put("ANIMAL", (ToolBox.poidsCritères[0][1])*100);
    //         this.valuePerCriterion.put("FOOD", (ToolBox.poidsCritères[0][1])*100);
    //         this.valuePerCriterion.put("HISTORY", (ToolBox.poidsCritères[0][1])*100);
    //     }
        
    //     // System.out.println(this.valuePerCriterion);
    //     // System.out.println(this.weightPerCriterion);

    //     for (String s: this.valuePerCriterion.keySet()) {
    //         // System.out.println("valeur : " + s + " : " + this.valuePerCriterion.get(s));
    //         // System.out.println(this.weightPerCriterion);

    //         if (!s.equals("TOTAL") && !s.equals("AGE") && !s.equals("ANIMAL")) {
    //             res += this.valuePerCriterion.get(s) * (1 + this.weightPerCriterion.get(s));
    //         } else {
    //             res += this.valuePerCriterion.get(s);
    //         }
    //     }

    
        
    //     double scoreFinal=0.0;
    //     for(String critere : valuePerCriterion.keySet()){
    //         scoreFinal+=valuePerCriterion.get(critere);
    //     }
    //     valuePerCriterion.put("TOTAL",scoreFinal);

    //     if(this.forbiddenFromPaired.contains(host)){
    //         valuePerCriterion.put("TOTAL",1000.0);
    //     }

    //     return valuePerCriterion;
        HashMap<String, Double> resultatPair=new HashMap<>();
        //Par souci d"affichage, on conserve le résultat de chaque étape
        resultatPair.put("GENDER", this.genderCriteria(matriceCout[1],host));            
        resultatPair.put("AGE", this.ageCriteria(matriceCout[2], host));
        resultatPair.put("HOBBIES", this.hobbyCriteria(matriceCout[3], host));
        resultatPair.put("ALLERGIES", this.animalCriteria(host));
        resultatPair.put("FOOD", this.foodCriteria(host));
        resultatPair.put("HISTORY", this.historyCriteria(host));


        System.out.println("Avant poids : \n"+resultatPair);

        for(String criterion: AdolescentPlus.weightPerCriterion.keySet()){
            if(resultatPair.containsKey(criterion)){
                double oldScore=resultatPair.get(criterion);
                double newScore=oldScore+weightPerCriterion.get(criterion);
                resultatPair.put(criterion, newScore);
            }
        }

        System.out.println("Apres poids : \n"+resultatPair);


        double scoreTotal=5.0;

        for(String etape: resultatPair.keySet()){
            scoreTotal+=resultatPair.get(etape);
        }
        resultatPair.put("TOTAL", scoreTotal);

        return resultatPair;

    }

        public static void main(String[] args){
            ImportExport ie=new ImportExport();
            ArrayList<AdolescentPlus> guestsPlus=AdolescentPlus.expandAdolescents(ie.importAdolescents("guests.csv"));
            ArrayList<AdolescentPlus> hostsPlus=AdolescentPlus.expandAdolescents(ie.importAdolescents("hosts.csv"));



            Pair test= new Pair(guestsPlus.get(0),hostsPlus.get(0));

            System.out.println("1 \n");

            System.out.println(test.getValeurCriterion());
            System.out.println("Total : "+test.getScore());

            Pair test2= new Pair(guestsPlus.get(0),hostsPlus.get(0));

            System.out.println("2 \n");

            System.out.println(test2.getValeurCriterion());
            System.out.println("Total : "+test2.getScore());


        }
}
