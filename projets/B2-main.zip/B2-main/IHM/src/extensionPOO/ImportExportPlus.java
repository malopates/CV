package extensionPOO;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import main.ImportExport;

// pas fini, si le temps on continue.
public class ImportExportPlus extends ImportExport {
    
    private final String PATHPOIDSCSV = ImportExport.getPath() + "poids.csv";
    private final String PATHWEIGHTCSV = ImportExport.getPath() + "weight.csv";

    public ImportExportPlus() {
        super();
    }

    public static double[][] importPoidsFromCSV() {
        double[][] poidsValues = new double[3][3];

        try {
            File f = new File(ImportExport.getPath() + "poids.csv");
            Scanner scanner = new Scanner(f);
            scanner.nextLine    ();

            scanner.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return poidsValues;
    }
}
