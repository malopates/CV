package extensionPOO;

import java.util.HashMap;

import main.*;

public class PairPlus extends Pair {
    
    HashMap<String,Double> criteriaScore;

    //Override CompatibilityScore pour return une hashMap ?

    public PairPlus(AdolescentPlus guest, AdolescentPlus host) {
        super(guest, host);// downcast, on perd ce qu'il y a dans l'adolescent
        

        this.criteriaScore = guest.compatibilityScore(host);
    }
}
