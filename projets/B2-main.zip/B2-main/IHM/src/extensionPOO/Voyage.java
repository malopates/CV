package extensionPOO;

import java.util.ArrayList;

import main.Historique;
import main.Pairing;
import mainIHM.SceneManager;

public class Voyage {

    public String fileName;
    public int nbLigne;
    public Pairing p;
    Historique histo = SceneManager.getHisto();


    public Voyage(String fileName, int nbLigne, Pairing p){
        this.fileName=fileName;
        this.nbLigne=nbLigne;
        this.p=p;
    }

    public Voyage(Pairing p){
        this(p.getFileName(), p.getNbLigne(), p);
    }
    
    public static ArrayList<Voyage> getVoyages(Historique histo){
        ArrayList<Pairing> allPairings=new ArrayList<>();
        for(Integer annee: histo.getHistoric().keySet()){
            allPairings.addAll(histo.getHistoric().get(annee));
        }
        ArrayList<Voyage> allVoyages=new ArrayList<>();

        for(Pairing p: allPairings){
            allVoyages.add(new Voyage(p));
        }
        return allVoyages;

    }

    public Pairing getP() {
        return p;
    }


}