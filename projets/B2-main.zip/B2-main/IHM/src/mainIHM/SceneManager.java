package mainIHM;

import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;
import main.Historique;
import mainIHM.controller.History;

public class SceneManager {
    
    // public static Historique histo=(new Historique()).loadHistoric();
    public static Historique histo=Historique.loadHistoric();


    public static Stage primaryStage;
    public static Stage popUpStage;

    public static Scene currentScene;

    public static HashMap<String, Scene> allScenes =new HashMap<>(); //Le string est le nom, associé à la scene
    static{
        if(primaryStage == null){ //Création d'un stage principal
            primaryStage=new Stage();
        }
        allScenes.put("History", History.getScene(primaryStage));
    }
    public static HashMap<String, String> allFXMLPaths =new HashMap<>();//Le nom associé au chemin
    static{
        allFXMLPaths.put("Accueil", "/fxml/accueil.fxml");
        allFXMLPaths.put("Pairing", "/fxml/pairing.fxml");
        allFXMLPaths.put("History", "null");
        allFXMLPaths.put("Calcul", "/fxml/Appariemments.fxml");
        allFXMLPaths.put("Import", "/fxml/import.fxml");
        allFXMLPaths.put("Aperçu", "null");
        allFXMLPaths.put("Liste", "/fxml/liste.fxml");


    }
    public static HashMap<String, Object> controllerMap=new HashMap<>();

    public static void setPrimaryStage(Stage primaryStage) {
        SceneManager.primaryStage = primaryStage;
    }

    public static void loadScene(String nomScene){

        try {//On va charger le FXML correspondant
            FXMLLoader loader = new FXMLLoader();
            URL fxmlFileUrl = SceneManager.class.getResource(SceneManager.allFXMLPaths.get(nomScene));
            if (fxmlFileUrl == null) {
                    System.out.println("Impossible de charger le fichier fxml");
                    System.exit(-1);
            }
            loader.setLocation(fxmlFileUrl);
            Parent root = loader.load();
        
            controllerMap.put(nomScene, loader.getController());

            Scene scene;
            switch (nomScene) {
                case "Import":
                    scene=new Scene(root,500,300);
                    break;

                case "History":
                    scene=new Scene(root);
                    break;
                default :
                    scene=new Scene(root,600,400);
                    break;
            }


            SceneManager.allScenes.put(nomScene,scene);
            System.out.println(nomScene+" chargé !");

        } catch (IOException e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
    }

    public static Scene getCurrentScene(){
        return SceneManager.currentScene;
    }

    public static void switchScene(String nomScene){
        if(primaryStage == null){ //Création d'un stage principal
            primaryStage=new Stage();
        }
        Scene scene=SceneManager.allScenes.get(nomScene);
        SceneManager.primaryStage.setScene(scene);
        SceneManager.currentScene=scene;     
        SceneManager.primaryStage.show();;
        SceneManager.primaryStage.setTitle(nomScene);
    }

    public static void createPopUp(String nomScene){
        if(popUpStage == null){ //Création d'un stage à popUp
            popUpStage=new Stage();
        }        
        Scene scene=SceneManager.allScenes.get(nomScene);

        SceneManager.popUpStage.setScene(scene);

        SceneManager.popUpStage.setX(SceneManager.primaryStage.getX()+SceneManager.primaryStage.getWidth());
        SceneManager.popUpStage.setY(SceneManager.primaryStage.getY());
        SceneManager.popUpStage.initModality(Modality.APPLICATION_MODAL);
        SceneManager.popUpStage.setResizable(false);
        SceneManager.popUpStage.setTitle(nomScene);

        // SceneManager.popUpStage.show();


        SceneManager.allScenes.put(nomScene,scene);
    }

    public static void showPopUp(){
        if(SceneManager.popUpStage!=null){
            SceneManager.popUpStage.show();
        }
        SceneManager.popUpStage=null;
    }

    public static void switchPopup(String nomScene){
        Scene scene=SceneManager.allScenes.get(nomScene);
        if(!SceneManager.popUpStage.getScene().equals(scene)){
            SceneManager.popUpStage.setScene(scene);
            
            SceneManager.popUpStage.setX(SceneManager.primaryStage.getX());
            SceneManager.popUpStage.setY(SceneManager.primaryStage.getY());
            SceneManager.popUpStage.initModality(Modality.APPLICATION_MODAL);
            SceneManager.popUpStage.setResizable(false);
            SceneManager.popUpStage.setTitle(nomScene);
        }
            
        SceneManager.popUpStage.show();
    }

    public static void closePopup(){
        SceneManager.popUpStage.close();
    }

    public static <T> T getController(String name){//Type générique pour s'adpater aux controlleurs
        return (T) controllerMap.get(name);//On cas pour récupérer le controlleur conrrespondant
    }

    public static Scene getScene(String nom){
        return allScenes.get(nom);
    }
    public static Historique getHisto(){
        return SceneManager.histo;
    }

}
