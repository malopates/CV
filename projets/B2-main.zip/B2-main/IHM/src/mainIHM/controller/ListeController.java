package mainIHM.controller;

import extensionPOO.AdolescentPlus;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.stage.Stage;
import main.Pair;

public class ListeController {
    @FXML
    private ListView<Pair> listesPaires;
    @FXML
    private ListView<AdolescentPlus> listesEnnemies;
    @FXML
    private Button deletePair;
    @FXML
    private Button deleteEnnemy;
    @FXML
    public Label labelSelec;

    public static ObservableList<Pair> pairs=FXCollections.observableArrayList();

    public static ObservableList<AdolescentPlus> ennemyList=FXCollections.observableArrayList();

    private AdolescentPlus selected;

    public void initialize(){
        listesPaires.setItems(pairs);
        listesEnnemies.setItems(ennemyList);

        deletePair.setOnAction(e ->{
            if(listesPaires.getSelectionModel().getSelectedItem()!=null){
            Pair aRemove=listesPaires.getSelectionModel().getSelectedItem();
            AdolescentPlus guest=(AdolescentPlus) aRemove.getGuest();
            AdolescentPlus host=(AdolescentPlus) aRemove.getHost();

            guest.setPresetPaired(null);
            host.setPresetPaired(null);

            pairs.remove(aRemove);    
            }
        });

        deleteEnnemy.setOnAction(e->{
            if(listesEnnemies.getSelectionModel().getSelectedItem()!=null){
                selected.getForbiddenFromPaired().remove(listesEnnemies.getSelectionModel().getSelectedItem());
            }
        });

        // if(PairingController.selectedGuest!=null){
        //     labelSelec.setText(PairingController.selectedGuest.toStringName());
        // }else{
        // }
    }

    

    public void setLabelSelecText(String text) {
        if (labelSelec != null) {
            labelSelec.setText("Sélection : "+text);
        }
    }
    public void setListeEnnemies(AdolescentPlus selected){
        ListeController.ennemyList.clear();
        this.selected=selected;
        System.out.println(selected.getForbiddenFromPaired());
        if(selected.getForbiddenFromPaired()!=null){
            ListeController.ennemyList.addAll(selected.getForbiddenFromPaired());
        }
    }

    public void goBack(ActionEvent event){
        System.out.println("HAHA");
        Node  source = (Node)  event.getSource(); 
        Stage stage  = (Stage) source.getScene().getWindow();
        stage.close();    
    }


}
