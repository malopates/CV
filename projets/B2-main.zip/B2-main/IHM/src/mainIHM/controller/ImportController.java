package mainIHM.controller;

import java.io.File;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.scene.Node;


public class ImportController {

    @FXML
    private ListView<String> guestListView;

    @FXML
    private ListView<String> hostListView;

    @FXML
    private Button parcourirGuest; //parcourir fichiers

    @FXML
    private Button supprGuest; //icone poubelle

    @FXML
    private Button parcourirHost; //paroucrir fichiers

    @FXML
    private Button supprHost; //icone poubelle

    @FXML
    private Button menu;

    
    @FXML
    private void initialize() { //a retirer si pas utilisé
        
    }

    @FXML
    private void onParcourirGuest() {
        File fichier = showFileChooser();
        guestListView.getItems().add(fichier.getName());
    }

    @FXML
    private void onParcourirHost() {
        File fichier = showFileChooser();
        hostListView.getItems().add(fichier.getName());
    }

    @FXML
    private void onSupprGuest() {
        guestListView.getItems().remove(guestListView.getSelectionModel().getSelectedItem());
    }

    @FXML
    private void onSupprHost() {
        hostListView.getItems().remove(guestListView.getSelectionModel().getSelectedItem()); 
    }

    @FXML
    private void retour(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow(); //Nom du stage n'existant pas en fxml, le récupérer depuis l'event
        stage.close();
    }

    private File showFileChooser() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setInitialDirectory(new File(System.getProperty("user.dir")+File.separator+"res"+File.separator+"imports"));
        FileChooser.ExtensionFilter fileExtensions =new FileChooser.ExtensionFilter("Comma Delimited (*.csv)", "*.csv");
        fileChooser.getExtensionFilters().add(fileExtensions);
        Stage currentStage = (Stage) menu.getScene().getWindow();
        return fileChooser.showOpenDialog(currentStage);
    }

    public void setGuestPath(MouseEvent e){
        if(e.getButton().equals(MouseButton.PRIMARY)){
            if(e.getClickCount()==2){
                PairingController.guestImportPath=guestListView.getSelectionModel().getSelectedItem();
                PairingController.reloadGuests();
            }
        }
    }
    public void setHostPath(MouseEvent e){
        if(e.getButton().equals(MouseButton.PRIMARY)){
            if(e.getClickCount()==2){
                PairingController.hostImportPath=hostListView.getSelectionModel().getSelectedItem();
                PairingController.reloadHosts();
            }
        }
    }

}