package mainIHM.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import mainIHM.SceneManager;

public class AccueilController {
    @FXML
    private Button goToPairing;

    @FXML
    private Button goToHistory;

    private void initialize() {
    }

    public void goToPairing(ActionEvent e){
        SceneManager.switchScene("Pairing");
    }

    public void goToHistory(ActionEvent e){
        SceneManager.switchScene("History");
    }

}
