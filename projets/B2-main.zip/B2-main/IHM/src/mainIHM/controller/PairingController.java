package mainIHM.controller;

import java.util.Collections;
import java.util.Stack;
import java.util.function.Predicate;

import extensionPOO.AdolescentPlus;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import main.ImportExport;
import main.Pair;
import mainIHM.SceneManager;



public class PairingController {
        @FXML private Label infoGuest;
        @FXML private Label infoHost;

        @FXML private ListView<AdolescentPlus> listeGuest;
        @FXML private ListView<AdolescentPlus> listeHost;

        @FXML private Button forceLink;
        @FXML private Button preventLink;
        @FXML public  Button afficheListe;

        @FXML private Button goToMenu;
        @FXML private Button importFile;
        @FXML private Button guestCan;
        @FXML private Button hostCan;
        @FXML private Button goToCalc;
        
        @FXML private TextField rechercheGuest;
        @FXML private TextField rechercheHost;

        @FXML private Button undoG;
        @FXML private Button undoH;

        @FXML private Label errorLabel;

        private static Stage listeStage=null;

        public static ObservableList<AdolescentPlus> guests=FXCollections.observableArrayList();
        public static ObservableList<AdolescentPlus> hosts=FXCollections.observableArrayList();

        public static String guestImportPath="";
        public static String hostImportPath="";

        public static AdolescentPlus selectedGuest;
        public static AdolescentPlus selectedHost;

        private ListeController listeController=SceneManager.getController("Liste");

        private static ImportExport ie=new ImportExport();

        private static Stack<AdolescentPlus> deletedGuests=new Stack<>();
        private static Stack<AdolescentPlus> deletedHosts=new Stack<>();

        public void initialize() {
                System.out.println("Initialisation...");
                PairingController.guestImportPath="guests.csv"; 
                PairingController.hostImportPath="hosts.csv";
                guests.addAll(AdolescentPlus.expandAdolescents(ie.importAdolescents(guestImportPath)));
                hosts.addAll(AdolescentPlus.expandAdolescents(ie.importAdolescents(hostImportPath)));
                System.out.println(hosts);

                infoGuest.setText("");
                infoHost.setText("");

                listeGuest.setItems(guests);
                listeHost.setItems(hosts);
                
                listeGuest.getSelectionModel().getSelectedItems().addListener(new ChangeListAdoGuest());
                listeHost.getSelectionModel().getSelectedItems().addListener(new ChangeListAdoHost());
                
                rechercheGuest.setStyle("-fx-text-inner-color: black;");

                errorLabel.setVisible(false);
                
                searchHost();
                searchGuest();
        }

        public void searchGuest() {
                FilteredList<AdolescentPlus> filteredGuests = new FilteredList<>(guests, p -> true);
                listeGuest.setItems(filteredGuests);

                rechercheGuest.textProperty().addListener((observable, oldValue, newValue) -> {
                        final String lowerCaseFilter = newValue.toLowerCase();

                        filteredGuests.setPredicate(guest -> {
                        if (newValue == null || newValue.isEmpty()) {
                                return true;
                        }
                return guest.toStringName().toLowerCase().contains(lowerCaseFilter);
                });
        });
}

        public static void reloadGuests(){
                guests.clear();
                guests.addAll(AdolescentPlus.expandAdolescents(ie.importAdolescents(guestImportPath)));
                Collections.sort(guests);
        }

        public static void reloadHosts(){
                hosts.clear();
                hosts.addAll(AdolescentPlus.expandAdolescents(ie.importAdolescents(hostImportPath)));
                Collections.sort(hosts);
        }
   
        class ChangeListAdoGuest implements ListChangeListener<AdolescentPlus> {
                public void onChanged(Change<? extends AdolescentPlus> report) {
                        AdolescentPlus selected=listeGuest.getSelectionModel().getSelectedItem();
                        infoGuest.setText(selected.toStringLong());
                        selectedGuest=selected;
                        System.out.println(selectedGuest.toStringName());
                        listeController.setLabelSelecText(selectedGuest.toStringName());
                        listeController.setListeEnnemies(selected);
                        securePreventAndForce();

                }
        }
        class ChangeListAdoHost implements ListChangeListener<AdolescentPlus>{
                public void onChanged(Change<? extends AdolescentPlus> report){
                        AdolescentPlus selected=listeHost.getSelectionModel().getSelectedItem();
                        infoHost.setText(selected.toStringLong());
                        selectedHost=selected;
                        securePreventAndForce();
                }
        }


        //Force et interdits
        public void addForce(ActionEvent event){
                if((selectedGuest.getPresetPaired()==null)&&(selectedHost.getPresetPaired()==null)){
                        selectedGuest.setPresetPaired(selectedHost);
                        selectedHost.setPresetPaired(selectedGuest);
                        ListeController.pairs.add(new Pair(selectedGuest, selectedHost));
                        securePreventAndForce();

                }
        }
        public void addForbidden(ActionEvent event){
                selectedGuest.addForbidden(selectedHost);
                selectedHost.addForbidden(selectedGuest);
                securePreventAndForce();

        }


        public void deleteGuest(ActionEvent event) {
                if(listeGuest.getSelectionModel().getSelectedItem()!=null){

                        deletedGuests.add(listeGuest.getSelectionModel().getSelectedItem());

                        guests.remove(listeGuest.getSelectionModel().getSelectedItem());
                        
                        
                        System.out.println("Guest supprimé");
                        if(listeGuest.getSelectionModel().getSelectedItem()==null){
                                infoGuest.setText("");
                        }
                        secureNextButton();

                }
        }

        public void undoDeleteGuest(){
                guests.add(deletedGuests.pop());
                // reloadGuests();
                secureNextButton();

        }
        



        public void deleteHost(ActionEvent event) {
                if(listeHost.getSelectionModel().getSelectedItem()!=null){
                        
                        deletedHosts.add(listeHost.getSelectionModel().getSelectedItem());
                        
                        hosts.remove(listeHost.getSelectionModel().getSelectedItem());
                        System.out.println("Host supprimé");
                        if(listeHost.getSelectionModel().getSelectedItem()==null){
                                infoHost.setText("");
                        }
                        // reloadHosts();
                        secureNextButton();

                }
        }
        public void undoDeleteHost(){
                hosts.add(deletedHosts.pop());
                secureNextButton();
                // reloadHosts();
        }

        public void secureNextButton(){
                if(
                        (listeGuest.getItems().size()!=listeHost.getItems().size())
                        ||
                        (listeGuest.getItems().isEmpty())
                        ||
                        (listeHost.getItems().isEmpty())
                        )
                {
                        goToCalc.setDisable(true);
                        errorLabel.setVisible(true);
                }else{
                        goToCalc.setDisable(false);
                        errorLabel.setVisible(false);

                }
        }
        public void securePreventAndForce(){
                if((listeGuest.getSelectionModel().getSelectedItem()!=null)&&(listeHost.getSelectionModel().getSelectedItem()!=null)){
                        
                        AdolescentPlus guestSelected=listeGuest.getSelectionModel().getSelectedItem();
                        AdolescentPlus hostSelected=listeHost.getSelectionModel().getSelectedItem();
                        if(guestSelected.getForbiddenFromPaired().contains(hostSelected)){
                                forceLink.setDisable(true);
                        }else
                        if((guestSelected.getPresetPaired()!=null)&&(guestSelected.getPresetPaired().equals(hostSelected))){
                                preventLink.setDisable(true);
                        }else{
                                forceLink.setDisable(false);
                                preventLink.setDisable(false);
                        }

                }else{
                        forceLink.setDisable(false);
                        preventLink.setDisable(false);

                }
                        
        }

        public void searchHost() {

        final FilteredList<AdolescentPlus> filteredHosts = new FilteredList<>(hosts, new Predicate<AdolescentPlus>() {
        @Override
                public boolean test(AdolescentPlus ado) {
                        return true; // autrement, filtre par défaut
                }
        });

        listeHost.setItems(filteredHosts);

        rechercheHost.textProperty().addListener(new ChangeListener<String>() {
                @Override
                public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                final String lowerCaseFilter = newValue.toLowerCase();

                // Redéfinit le prédicat à chaque changement de texte
                filteredHosts.setPredicate(new Predicate<AdolescentPlus>() {
                        @Override
                        public boolean test(AdolescentPlus host) {
                        if (newValue == null || newValue.isEmpty()) {
                                return true;
                        }

                        // Adapte selon la méthode pour afficher le nom
                        return host.toStringName().toLowerCase().contains(lowerCaseFilter);
                        }
                });
                }
        });
}

        //Pop-UP
        public void openImport(ActionEvent event){
                // try{
                //         FXMLLoader loader=new FXMLLoader(getClass().getResource("importExport.fxml"));
                //         Parent root=loader.load();

                //         Stage stage=new Stage();
                //         stage.setTitle("Imports");
                //         Scene scene=new Scene(root);
                //         stage.initModality(Modality.APPLICATION_MODAL);
                //         stage.setResizable(false);
                //         stage.setScene(scene);
                //         stage.show();
                // }catch(Exception e){
                //         System.out.println("Impossible de trouver le fichier XML");
                // }
                SceneManager.createPopUp("Import");
                SceneManager.showPopUp();
                // SceneManager.switchPopup("Import");        
                }

        //
        public void switchToCalc(ActionEvent event){
                SceneManager.switchScene("Calcul");
        }
        
        public void switchToMenu(ActionEvent event){
                SceneManager.switchScene("Accueil");
        }

        public void afficherListe(ActionEvent event){

                Stage stage=new Stage();
                PairingController.listeStage=stage;
                stage.setTitle(guestImportPath);
                stage.setTitle("Restrictions");
                Scene scene = SceneManager.getScene("Liste");
                stage.initModality(Modality.NONE);
                stage.setResizable(true);
                stage.setScene(scene);
                stage.show();               
        }
}
