package mainIHM.controller;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import extensionPOO.AdolescentPlus;
import extensionPOO.PairPlus;
import javafx.animation.PauseTransition;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Slider;
import javafx.scene.image.ImageView;
import javafx.util.Duration;
import main.Adolescent;
import main.Hungorithm;
import main.ImportExport;
import main.Main;
import main.Pair;
import main.Pairing;
import mainIHM.SceneManager;

public class AppariemmentsController {
    private String PATH = System.getProperty("user.dir") + File.separator + "res" + File.separator + "weight.csv";
    
    @FXML
    Button calculButton;

    @FXML
    Button backButton;

    @FXML
    Button exportButton;

    @FXML
    Button homeButton;

    @FXML
    Slider hobbiesSlider;

    @FXML
    Slider historySlider;
    
    @FXML
    Slider genderSlider;
    
    @FXML
    Slider foodSlider;
    
    @FXML
    Slider allergiesSlider;

    @FXML
    Label hobbiesLabelSlider;

    @FXML
    Label historyLabelSlider;

    @FXML
    Label genderLabelSlider;

    @FXML
    Label foodLabelSlider;

    @FXML
    Label allergiesLabelSlider;

    @FXML
    Label calculLabel;

    @FXML
    Label hobbiesLabel;

    @FXML
    Label historyLabel;

    @FXML
    Label genderLabel;

    @FXML
    Label foodLabel;

    @FXML
    Label allergiesLabel;

    @FXML
    Label ageLabel;

    @FXML
    ListView<Pair> pairListView;

    @FXML
    private ImageView chargementImageView;



    // corriger les images
    // corriger les buttons
    public void initialize() {
        // Mettre les sliders en valeurs par défauts, adapter criteriaSlider pour que ça corresponde
        // CODE POO
        hobbiesLabel.setVisible(false);
        historyLabel.setVisible(false);
        genderLabel.setVisible(false);
        foodLabel.setVisible(false);
        allergiesLabel.setVisible(false);
        ageLabel.setVisible(false);

        try {
            getSlidersValuesFromFile();
        } catch (IOException e) {
            e.printStackTrace();
        }

        updateCriteriaLabel();

        hobbiesSlider.valueProperty().addListener((observable, oldValue, newValue) -> {
            updateCriteriaLabel();
            AdolescentPlus.fetchNewWeights();
        });

        historySlider.valueProperty().addListener((observable, oldValue, newValue) -> {
            updateCriteriaLabel();
            AdolescentPlus.fetchNewWeights();
        });

        genderSlider.valueProperty().addListener((observable, oldValue, newValue) -> {
            updateCriteriaLabel();
            AdolescentPlus.fetchNewWeights();
        });

        foodSlider.valueProperty().addListener((observable, oldValue, newValue) -> {
            updateCriteriaLabel();
            AdolescentPlus.fetchNewWeights();
        });

        allergiesSlider.valueProperty().addListener((observable, oldValue, newValue) -> {
            updateCriteriaLabel();
            AdolescentPlus.fetchNewWeights();
        });

        chargementImageView.setVisible(false);
        pairListView.getSelectionModel().getSelectedItems().addListener(new ChangePairListView());
    }

    class ChangePairListView implements ListChangeListener<Pair> {
        public void onChanged(Change<? extends Pair> report) {
            Pair selected = pairListView.getSelectionModel().getSelectedItem();
            hobbiesLabel.setVisible(true);
            historyLabel.setVisible(true);
            genderLabel.setVisible(true);
            foodLabel.setVisible(true);
            allergiesLabel.setVisible(true);
            System.out.println(selected.getValeurCriterion());            
            HashMap<String,Double> tmp = selected.getValeurCriterion();
            hobbiesLabel.setText("HOBBIES : "+tmp.get("HOBBIES").toString());
            historyLabel.setText("HISTORY  :"+tmp.get("HISTORY").toString());
            genderLabel.setText("GENDER : "+tmp.get("GENDER").toString());
            foodLabel.setText("FOOD : "+tmp.get("FOOD").toString());
            allergiesLabel.setText("ALLERGIES : "+tmp.get("ALLERGIES").toString());
            ageLabel.setText("AGE : "+tmp.get("AGE").toString());
        }
    }

    private void getSlidersValuesFromFile() throws IOException{
        Scanner scanner = new Scanner(new File(PATH));
        scanner.nextLine();
        hobbiesSlider.setValue(-1 * Double.valueOf(scanner.nextLine().split(";")[1]));
        historySlider.setValue(Double.valueOf(scanner.nextLine().split(";")[1]));
        genderSlider.setValue(Double.valueOf(scanner.nextLine().split(";")[1]));
        foodSlider.setValue(Double.valueOf(scanner.nextLine().split(";")[1]));
        allergiesSlider.setValue(Double.valueOf(scanner.nextLine().split(";")[1]));
        scanner.close();
    }
// TODO : rajouter un slider
    private void writeSlidersValuesToFile() {
        try {
            FileWriter fw = new FileWriter(new File(PATH));
            String result = "Criterion;Weight\n" +
                                "HOBBIES;" + (int) (-1) * hobbiesSlider.getValue() + "\n" +
                                "HISTORY;" + (int) historySlider.getValue() + "\n" +
                                "GENDER; " + (int) genderSlider.getValue() + "\n" +
                                "FOOD;" + (int) foodSlider.getValue() + "\n" + 
                                "ALLERG;" + (int) allergiesSlider.getValue();
            fw.write(result);
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void updateCriteriaLabel() {
        String hobbiesValue = "" + (int) hobbiesSlider.getValue();
        String historyValue = "" + (int) historySlider.getValue();
        String genderValue = "" + (int) genderSlider.getValue();
        String foodValue = "" + (int) foodSlider.getValue();
        String allergiesValue = "" + (int) allergiesSlider.getValue();
        
        hobbiesLabelSlider.setText(hobbiesValue);
        historyLabelSlider.setText(historyValue);
        genderLabelSlider.setText(genderValue);
        foodLabelSlider.setText(foodValue);
        allergiesLabelSlider.setText(allergiesValue);
    }

    public void pressedButtonCalcul(ActionEvent event) throws InterruptedException, IOException {
        writeSlidersValuesToFile();
        pairListView.getItems().clear();
        // Afficher le GIF de chargement le temps du calcul
        chargementImageView.setVisible(true);
        // Récupérer les Adolescents

        PauseTransition pause = new PauseTransition(Duration.seconds(1.5));
        pause.setOnFinished(e -> chargementImageView.setVisible(false));
        pause.play();

        ArrayList<AdolescentPlus> hostAdolescents = new ArrayList<>(PairingController.hosts);

        ArrayList<AdolescentPlus> guestAdolescents = new ArrayList<>(PairingController.guests); // on suppose qu'il sont dedans

        Main main = new Main();
        
        //ArrayList<PairPlus> predef=PairingController.getPredf();
        //predef.add(PairPlus.expandPair(main.removeBFFs(guestAdolescents, hostAdolescents))); // convertir les aado+ en ado, convert en observablelist puis ajout de la listview

        Pair[][] pairMatrix = main.makeAPairingMatrixPlus(hostAdolescents, guestAdolescents);
        double[][] scoreMatrix = main.getTheScoreMatrix(pairMatrix);
        
        //Utiliser Hungorithm
        try {
            ArrayList<Integer[]> resultHungorithm =  Hungorithm.hungorithm(scoreMatrix);
            
            for (Integer[] lig: resultHungorithm) {
                    pairListView.getItems().add(pairMatrix[lig[0]][lig[1]]);
            }
            // Enlever le GIF
            
            
            chargementImageView.setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void pressButtonExport(ActionEvent event) {
        // Récupérer les Pairs de la listView, les transformers en Pairing
        // Call exportPairing
        ImportExport impexp = new ImportExport();
        ObservableList<Pair> obsList = pairListView.getItems();
        ArrayList<Pair> aryList = new ArrayList<>(obsList);
        Pairing pairing = new Pairing(LocalDate.now(), obsList.get(0).getGuest().getBIRTHCOUNTRY(), obsList.get(0).getHost().getBIRTHCOUNTRY(), aryList);
        impexp.exportPairing(pairing);


        // SceneManager.histo.historic.get(pairing.getPairingDate().getYear()).add(pairing);
        // SceneManager.histo.historic.saveHistoric();
    }

    public void pressedButtonHome(ActionEvent event) throws IOException { 
        SceneManager.switchScene("Accueil");
    }

    public void pressButtonBack(ActionEvent event) throws IOException {
        SceneManager.switchScene("Pairing");
    }
}
