package mainIHM.controller;

import extensionPOO.Voyage;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import main.Pairing;
import mainIHM.SceneManager;

public class History {





    public static Scene getScene(Stage primaryStage) {
        boolean aDroite = true; 
        Label titleLabel = new Label("HISTORY");
        titleLabel.setStyle("-fx-text-fill: #FFF3B0; -fx-font-weight: bolder; -fx-font-size: 24px;");

        Image homeImage = new Image("/icons/home.png");
        ImageView homeView = new ImageView(homeImage);
        homeView.setFitWidth(20);
        homeView.setFitHeight(20);
        Button homeButton = new Button();
        homeButton.setGraphic(homeView);
        homeButton.setStyle("-fx-background-color:lightblue;");
        homeButton.setOnAction(e->{
            SceneManager.switchScene("Accueil");
        });

        Region topBarSpacer = new Region();
        HBox.setHgrow(topBarSpacer, Priority.ALWAYS);
        HBox topBar = new HBox(titleLabel, topBarSpacer, homeButton);

        ListView<Voyage> listView = new ListView<>();
        VBox listContainer = new VBox(listView);
        listContainer.setPadding(new Insets(0, 50, 50, 20));


        for (Voyage v : listView.getItems()) {
        
            System.out.println(v.fileName);
        }

        listView.setCellFactory(lv -> new VoyageCell());


        listView.getItems().addAll(Voyage.getVoyages(SceneManager.getHisto()));

        listView.setOnKeyPressed(event -> {
            if (event.getCode() == javafx.scene.input.KeyCode.DELETE) {
            Voyage selected = listView.getSelectionModel().getSelectedItem();
            if (selected != null) {
                listView.getItems().remove(selected);
            }
            }
        });



    


        VBox root = new VBox(topBar, listContainer);
        root.setStyle("-fx-background-color: linear-gradient(to top, #3E6887, #3E6887, #5698C8);");

        Scene scene = new Scene(root, 600, 400);
        listView.maxWidthProperty().bind(scene.widthProperty().multiply(0.90));

        listView.setOnMouseClicked(event -> {
            if (event.getClickCount() == 2) {
                Voyage selected = listView.getSelectionModel().getSelectedItem();
                if (selected != null) {
                    voirPreview(selected, primaryStage, aDroite);
                }
            }
        });

        return scene;
    }

    private static class VoyageCell extends ListCell<Voyage> {
        private final HBox content;
        private final Text fileNameText = new Text();
        private final Text fileSizeText = new Text();
        private final Button deleteButton = new Button();
        private final ImageView trashIcon;
        private final Region spacer = new Region();

        private static final Image TRASH_IMAGE = new Image("/icons/trash.png");

        public VoyageCell() {
            trashIcon = new ImageView(TRASH_IMAGE);
            deleteButton.setGraphic(trashIcon);
            deleteButton.setStyle("-fx-background-color: transparent;");

            HBox.setHgrow(spacer, Priority.ALWAYS);
            HBox infoBox = new HBox(fileNameText, fileSizeText, spacer, deleteButton);
            infoBox.setSpacing(40);

            content = new HBox(infoBox);
            content.setSpacing(10);

            deleteButton.setOnAction(e -> {
                Voyage item = getItem();
                if (item != null) {
                    if(notifierSur())

                    for(Integer year: SceneManager.histo.historic.keySet()){
                        for(Pairing p : SceneManager.histo.historic.get(year)){
                            if (item.getP().equals(p)){
                                SceneManager.histo.historic.get(year).remove(p);
                                SceneManager.histo.saveHistoric();
                                break;
                            }
                        }
                    }


                    getListView().getItems().remove(item);
                    
                }
            });
        }

        @Override
        protected void updateItem(Voyage voyage, boolean empty) {
            super.updateItem(voyage, empty);
            if (empty || voyage == null) {
                setGraphic(null);
            } else {
                fileNameText.setText(voyage.fileName);
                fileSizeText.setText(voyage.nbLigne + "adolescent.es");

                if (isSelected()) {
                    fileNameText.setStyle("-fx-font-weight: bold; -fx-font-size: 16px; -fx-fill: white;");
                    fileSizeText.setStyle("-fx-fill: white;");
                    trashIcon.setFitWidth(35);
                    trashIcon.setFitHeight(35);
                } else {
                    fileNameText.setStyle("-fx-font-weight: normal; -fx-font-size: 14px; -fx-fill: black;");
                    fileSizeText.setStyle("-fx-font-size: 12px; -fx-fill: black;");
                    trashIcon.setFitWidth(30);
                    trashIcon.setFitHeight(30);
                }

                setGraphic(content);
            }
        }
    }

        //alerte gestion erreur suppression

    public static boolean notifierSur(){
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Continuer ?", ButtonType.YES, ButtonType.NO);
        alert.setTitle("Êtes-vous sûr.es ?");
        alert.showAndWait();

        ButtonType result = alert.getResult();
        return result != null && result == ButtonType.YES; //si l'user ferme la fenetre sans rien choisir
        }


    private static void voirPreview(Voyage voyage, Stage ownerStage, boolean aDroite) {
        
        Stage apercu = new Stage();
        apercu.setTitle(voyage.fileName);

        VBox fond = new VBox();
        fond.setStyle("-fx-background-color: linear-gradient(to top, #3E6887, #3E6887, #5698C8);");

        Label titre = new Label(voyage.fileName);
        Label infos = new Label("Taille fichier : " + voyage.nbLigne + " Ko");
        titre.setStyle("-fx-text-fill: #FFF3B0; -fx-font-weight: bolder; -fx-font-size: 24px;");
        infos.setStyle("-fx-text-fill:rgb(255, 255, 255); -fx-font-size: 18px;");
        fond.getChildren().addAll(titre, infos);

        Scene scene = new Scene(fond, 400, 600);
        apercu.setScene(scene);

        if (aDroite) {
            apercu.setX(ownerStage.getX() + ownerStage.getWidth() + 10);
        } else {
            apercu.setX(ownerStage.getX() - 400 - 10);
        }
        apercu.setY(ownerStage.getY());
        aDroite = !aDroite;

        apercu.show();
    }
}
