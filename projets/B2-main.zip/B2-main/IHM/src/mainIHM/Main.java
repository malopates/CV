package mainIHM;

import javafx.application.Application;
import javafx.stage.Stage;

public class Main extends Application {
    @Override


    

    public void start(Stage primaryStage) {
        SceneManager.setPrimaryStage(primaryStage);
    
        SceneManager.loadScene("Accueil");
        SceneManager.loadScene("Liste");
        SceneManager.loadScene("Pairing");
        SceneManager.loadScene("Import");
        SceneManager.loadScene("Calcul");

        SceneManager.createPopUp("Import");


        SceneManager.switchScene("Accueil");
    }
    public static void main(String[] args) {
        launch(args);
    }
}


// MANQUE :

// LISTE FEATURES
// OVERRIDE COMPATIBILITYSCORE()
// REWORK MAIN.CALCUL POUR ADO+
// AVERTISSEMENT LISTS INEGALES
// TRANSISTION PAGES FONCTIONNELLES
// HISTORY
// SEARCH BAR
// COULEURS
// POIDS SLIDERS ET DETAIL CALCUL
// IMAGES
// RECUPERER LES ADO DANS LES CSV (PAIRING)
// IMPORT -> PAIRING FILE