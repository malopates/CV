#Gestionnaire échange linguistique

Ce projet est une application Java pour gérer des échanges linguistiques entre adolescent de divers pays, dans le cadre d'un projet pluridisciplinaire entre OOP, Graphes et IHM.

Outils nécessaire : 
- Java
- Git (optionnel)
- Un IDE compatible Java

Installation :
- 'git clone https://gitlab.univ-lille.fr/sae2.01-2.02/2025/B2'
- 'git clone git@gitlab-ssh.univ-lille.fr:sae2.01-2.02/2025/B2.git'

Génération de la documentation (depuis la racine du projet) :
- 'javadoc -d doc/ -sourcepath src/main/ -charset UTF-8 -author -version src/main/*.java'

Les tests sont à executer dans un IDE avec les extensions Java Test...

- Malori Alvarez
- Louis Huard
- Ulysse Petillon

Remarques : 
- Projet en cours de développement.
- Pour exectuer directement l'IHM via VSCode, il faut mettre src et IHM/src en sourcepath

JAR : Voici les commandes utilisés pour créer le .jar
```
mkdir -p build/classes
mkdir -p build/resources

cp -r IHM/src/fxml build/resources/
cp -r IHM/src/icons build/resources/
cp -r res build/resources/

javac --module-path /path/to/javafx/lib --add-modules javafx.controls,javafx.fxml -d build/classes src/main/*.java IHM/src/extensionPOO/*.java IHM/src/mainIHM/*.java IHM/src/mainIHM/controller/*.java src/main/enums/* src/main/exceptions/*

jar cfm DuoGesseur.jar manifest.txt -C build/classes . -C build/resources .

java --module-path /path/to/javafx/lib/ --add-modules javafx.controls,javafx.fxml -jar DuoGesseur.jar
```


