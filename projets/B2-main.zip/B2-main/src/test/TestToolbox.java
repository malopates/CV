package test;

import static org.junit.Assert.*;
import org.junit.jupiter.api.*;

import main.ToolBox;

public class TestToolbox {

    @Test
    public void testStringToBoolean() {
        // a complleter + mettre les méthodes de toolbox en public ?!
        assertTrue(ToolBox.stringToBoolean("yes"));
        assertFalse(ToolBox.stringToBoolean("no"));
    }

    @Test
    public void testIsAmong() {
        // a completer
        assertTrue(ToolBox.isAmong("politics","chess", "football", "politics"));
        assertFalse(ToolBox.isAmong("cooking", "drinking", "football", "video games", "nothing"));
        assertTrue(ToolBox.isAmong("Pirates", "pirates", "theologie", "gaming", "football"));
        assertTrue(ToolBox.isAmong("", "other", "", "female"));
    }
}
