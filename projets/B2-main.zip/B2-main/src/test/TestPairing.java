package test;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import main.Pairing;

public class TestPairing {
    Pairing pairing;

    @BeforeEach
    public void initialization() {
        // à completer
    }

    @Test
    public void testExportPairing() {
        // à completer
    }
}
