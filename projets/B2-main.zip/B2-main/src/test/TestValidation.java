package test;


import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.File;
import java.io.FileNotFoundException;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import main.Validation;
import main.exceptions.*;

public class TestValidation {
    static String PATH;
    
    @BeforeAll
    public static void initialization() {
        PATH = System.getProperty("user.dir")+File.separator+"B2"+File.separator+"res"+File.separator+"imports"+File.separator;
    }

    @Test
    public void  testCheckFile() {
        try {
        assertTrue(Validation.checkFile(PATH+"guests.csv"));
        assertFalse(Validation.checkFile(PATH+"hostsFailed.csv"));
        } catch (FileNotFoundException e) {
            System.err.println(e);
        } catch (InvalidStructureException e) {
            System.err.println(e);
        }

        assertThrows(FileNotFoundException.class, () -> { Validation.checkFile(PATH + "nonexistent.csv");}
        , "FileNotFoundException était attendue");
        
        //String path2 = "/home/nyaa/Documents/IUT/S2/S2.01-2.02/B2/res/imports/invalidStructure.csv";

        // assertThrows(InvalidStructureException.class, () -> { Validation.checkFile(path2);}
        // , "InvalidStructureException était attendue"); 

        // Passe chez moi avec un chemin absolu mais pas avec PATH+"invalidStructure.csv" jsp pourquoi. (Trouve pas le file)
    }
    
}
