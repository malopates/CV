package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import main.Adolescent;
import main.ToolBox;
import main.enums.Criterion;

public class TestAdolescent {
 public Adolescent genderCriteriaWrong;

 HashMap<Criterion, String> criteriaWrong=new HashMap<>();

 public Adolescent animalYetAllergic;
 public Adolescent illogicalAdo;

 public Adolescent ado1;
 public Adolescent ado2;
 public Adolescent ado2Bis;

 public Adolescent ado3;

 
 public Adolescent frenchie;
 
 double[][] matriceCout = ToolBox.poidsCritères;

 public Adolescent countryWrong;

 @BeforeEach
 public void testInitialization(){


 // non coherent à cause du gender
 
 
 
 //Les cohérents et logiques
 
 HashMap<Criterion, String> criteriaAdo1 = new HashMap<Criterion, String>();
 criteriaAdo1.put(Criterion.GUEST_ANIMAL_ALLERGY, "no");
 criteriaAdo1.put(Criterion.HOST_HAS_ANIMAL, "no");
 criteriaAdo1.put(Criterion.HOBBIES, "drawing, culture, working");
 criteriaAdo1.put(Criterion.GENDER, "Female");
 criteriaAdo1.put(Criterion.PAIR_GENDER, "Male");
 criteriaAdo1.put(Criterion.HISTORY, "");
 
 ado1 = new Adolescent("Hayao", "Miyazaki", "female",  "2006-10-12", "ES", criteriaAdo1);
 
 
 
 HashMap<Criterion, String> criteriaAdo2 = new HashMap<Criterion, String>();
 criteriaAdo2.put(Criterion.GUEST_ANIMAL_ALLERGY, "no");
 criteriaAdo2.put(Criterion.HOST_HAS_ANIMAL, "yes");
 criteriaAdo2.put(Criterion.HOBBIES, "guns, church, Elon Musk");
 criteriaAdo2.put(Criterion.GENDER, "Male");
 criteriaAdo2.put(Criterion.PAIR_GENDER, "Female");
 criteriaAdo2.put(Criterion.HISTORY, "");
 //passe les test (normalement)
 
 ado2 = new Adolescent("Trump", "Donald", "male", "2001-09-10", "IT", criteriaAdo2);
 
 
 
 
 HashMap<Criterion, String> criteriaAdo2Bis = new HashMap<Criterion, String>();
 criteriaAdo2Bis.put(Criterion.GUEST_ANIMAL_ALLERGY, "no");
 criteriaAdo2Bis.put(Criterion.HOST_HAS_ANIMAL, "yes");
 criteriaAdo2Bis.put(Criterion.HOBBIES, "guns, church, Elon Musk");
 criteriaAdo2Bis.put(Criterion.GENDER, "Male");
 criteriaAdo2Bis.put(Criterion.PAIR_GENDER, "Female");
 criteriaAdo2Bis.put(Criterion.HISTORY, "");
 //passe les test (normalement)
 
ado2Bis = new Adolescent("Trump", "Donald", "male", "2001-09-10", "IT", criteriaAdo2Bis);
 
 
 HashMap<Criterion, String> criteriaAdo3 = new HashMap<Criterion, String>();
 criteriaAdo3.put(Criterion.GUEST_ANIMAL_ALLERGY, "no");
 criteriaAdo3.put(Criterion.HOST_HAS_ANIMAL, "yes");
 criteriaAdo3.put(Criterion.HOBBIES, "party, culture, skydiving");
 criteriaAdo3.put(Criterion.GENDER, "Other");
 criteriaAdo3.put(Criterion.PAIR_GENDER, "Male");
 criteriaAdo3.put(Criterion.HISTORY, "");
 //passe les test (normalement)
 ado3 = new Adolescent("Gilbert", "France", "other", "2006-10-13", "FR", criteriaAdo3);
 
 HashMap<Criterion, String> criteriaFrenchie = new HashMap<Criterion, String>();
 criteriaFrenchie.put(Criterion.GUEST_ANIMAL_ALLERGY, "no");
 criteriaFrenchie.put(Criterion.HOST_HAS_ANIMAL, "yes");
 criteriaFrenchie.put(Criterion.HOBBIES, "party, guns, church");
 criteriaFrenchie.put(Criterion.GENDER, "OTHER");
 criteriaFrenchie.put(Criterion.PAIR_GENDER, "FEMALE");
 criteriaFrenchie.put(Criterion.HISTORY, "");
 //0 Hobby en commun avec ado1, 1 avec ado3,2 avec
 frenchie = new Adolescent("Buonaparte", "Napoleon", "male", "1769-08-15", "FR", criteriaFrenchie);
 

 
//Hashmap de critères 
 criteriaWrong.put(Criterion.GUEST_ANIMAL_ALLERGY, "yes");
 criteriaWrong.put(Criterion.HOST_HAS_ANIMAL, "no");
//  criteriaWrong.put(Criterion.GUEST_FOOD, "");
 criteriaWrong.put(Criterion.HOST_FOOD, "");
 criteriaWrong.put(Criterion.HOBBIES, "");
 criteriaWrong.put(Criterion.GENDER, "male");
 criteriaWrong.put(Criterion.PAIR_GENDER, "male");
 criteriaWrong.put(Criterion.HISTORY, "");
 }

//  @Test
//  public void testIsLogical() {
//  //Test des critères à valeurs prédéfinies (ergo. String)
//  illogicalAdo=new Adolescent("", "", "male", "2007-08-24", "FR", criteriaWrong);
//  assertTrue(illogicalAdo.logicalCriteria());

//  criteriaWrong.put(Criterion.GENDER, "truck");
//  assertFalse(illogicalAdo.logicalCriteria());
//  criteriaWrong.put(Criterion.GENDER, "male");
//  criteriaWrong.put(Criterion.GUEST_FOOD, "hungry");
//  assertFalse(illogicalAdo.logicalCriteria());
//  criteriaWrong.put(Criterion.GUEST_FOOD, "");
 
//  //Test des booléens
//  criteriaWrong.put(Criterion.GUEST_ANIMAL_ALLERGY, "oui");
//  assertFalse(illogicalAdo.logicalCriteria());
//  criteriaWrong.put(Criterion.GUEST_ANIMAL_ALLERGY, "yes");

//  //Test spécifique : PAIR_GENDER, ""
//  criteriaWrong.put(Criterion.PAIR_GENDER, "");
//  assertTrue(illogicalAdo.logicalCriteria());

//  //Les logiques
//  assertTrue(ado1.logicalCriteria());
//  assertTrue(ado2.logicalCriteria());
//  }


 @Test
 public void testIsCoherent() {
 //Test des critères + de l'attribut gender
 criteriaWrong.put(Criterion.GENDER,"truck");
 genderCriteriaWrong = new Adolescent("Griffin", "Peter", "male","2005-01-31", "GE", criteriaWrong);
 assertFalse(genderCriteriaWrong.isCoherent());
 criteriaWrong.put(Criterion.GENDER,"female");
 assertFalse(genderCriteriaWrong.isCoherent());
 criteriaWrong.put(Criterion.GENDER,"male");
 assertTrue(genderCriteriaWrong.isCoherent());
 //Pays
 countryWrong = new Adolescent("Hanouna", "Cyril", "male", "2007-08-24", "FRE", criteriaWrong);
 assertFalse(countryWrong.isCoherent());

 //Animal
 criteriaWrong.put(Criterion.GUEST_ANIMAL_ALLERGY, "yes");
 criteriaWrong.put(Criterion.HOST_HAS_ANIMAL, "yes");
 animalYetAllergic = new Adolescent("Hanouna", "Cyril", "male", "2007-08-24", "FR", criteriaWrong);
 assertFalse(animalYetAllergic.isCoherent());

 //Les coherents
 assertTrue(ado1.isCoherent());
 assertTrue(ado3.isCoherent());
 }



 @Test

 // à vérifier avec louis
 public void testGenderCriteria() {
 // double[][] matriceCout = ToolBox.poidsCritères;

 // 0 si pas rempli, -1 si un rempli et -2 si deux rempli (ou vide)
 assertEquals(0.0, frenchie.genderCriteria(matriceCout[1], ado3),0.0001); 
 assertEquals(-1.0, ado3.genderCriteria(matriceCout[1], ado2),0.0001); 
 assertEquals(-2.0, ado2.genderCriteria(matriceCout[1], ado1),0.0001); 
 }
// Ado1 GENDER: FEMALE / PAIR_GENDER : MALE
// Ado2 GENDER: MALE / PAIR_GENDER : FEMALE
// Frenchie GENDER : OTHER / PAIR_GENDER : FEMALE
// Ado3 GENDER : OTHER / PAIR_GENDER : MALE

 @Test
 public void testAgeCriteria() {
 assertEquals(0.0,ado2.ageCriteria(matriceCout[2],ado1),0.0001);
 assertEquals(0.0,ado2.ageCriteria(matriceCout[2],ado3),0.0001);
 assertEquals(-1.0,ado3.ageCriteria(matriceCout[2],ado1),0.0001);
 }

// Ado1 : 2006-10-12
// Ado2 : 2001-09-10
// Ado3 : 2006-10-13
 
 @Test
 public void testHobbyCriteria() {
 assertEquals(0.0,ado1.hobbyCriteria(matriceCout[3],ado2),0.001);
 assertEquals(-0.5,frenchie.hobbyCriteria(matriceCout[3],ado3),0.0001);
 assertEquals(-1.0,frenchie.hobbyCriteria(matriceCout[3],ado2),0.0001);
 assertEquals(100.0,frenchie.hobbyCriteria(matriceCout[3],ado1),0.0001);
 }

// Ado1 : 0 hobbies en commun avec Ado2
// Ado1 : 0 hobbies en commun avec frenchie
// Ado2 : 1 hobby en commun avec frenchie
// Ado3 : 2 hobbies en commun avec frenchie


 
@Test
public void testAnimalCriteria(){
//Frenchie a un animal
Adolescent dogMeat=new Adolescent("null", "null", "male", null, "FR", criteriaWrong);
dogMeat.getCriteria().put(Criterion.GUEST_ANIMAL_ALLERGY, "no");
assertEquals(0, dogMeat.animalCriteria(frenchie), 0.0001);

Adolescent dogHater=new Adolescent("null", "null", "male", null, "FR", criteriaWrong);
dogHater.getCriteria().put(Criterion.GUEST_ANIMAL_ALLERGY, "yes");
assertEquals(matriceCout[0][1], dogHater.animalCriteria(frenchie), 0.0001);


}

@Test
public void testFoodCriteria(){
    HashMap<Criterion,String> criteriaVege=new HashMap<>();
    criteriaVege.put(Criterion.GUEST_ANIMAL_ALLERGY, "yes");
    criteriaVege.put(Criterion.HOST_HAS_ANIMAL, "no");
    // criteriaVege.put(Criterion.GUEST_FOOD, "vegetarian");
    criteriaVege.put(Criterion.HOST_FOOD, "vegetarian");
    criteriaVege.put(Criterion.HOBBIES, "");
    criteriaVege.put(Criterion.GENDER, "male");
    criteriaVege.put(Criterion.PAIR_GENDER, "");
    criteriaVege.put(Criterion.HISTORY, "");
    Adolescent vegetar=new Adolescent("null", "null", "male", null, "FR", criteriaVege);

    HashMap<Criterion,String> criteriaNoNuts=new HashMap<>();
    criteriaNoNuts.put(Criterion.GUEST_ANIMAL_ALLERGY, "yes");
    criteriaNoNuts.put(Criterion.HOST_HAS_ANIMAL, "no");
    // criteriaNoNuts.put(Criterion.GUEST_FOOD, "nonuts");
    criteriaNoNuts.put(Criterion.HOST_FOOD, "nonuts");
    criteriaNoNuts.put(Criterion.HOBBIES, "");
    criteriaNoNuts.put(Criterion.GENDER, "male");
    criteriaNoNuts.put(Criterion.PAIR_GENDER, "");
    criteriaNoNuts.put(Criterion.HISTORY, "");
    Adolescent nonuts=new Adolescent("null", "null", "male", null, "FR", criteriaNoNuts);

    Adolescent nonuts_vegetar=new Adolescent("null", "null", "male", null, "FR", criteriaWrong);
    // nonuts_vegetar.getCriteria().put(Criterion.GUEST_FOOD, "nonuts,vegetarian");
    nonuts_vegetar.getCriteria().put(Criterion.HOST_FOOD, "vegetarian,nonuts");

    assertEquals(0, vegetar.foodCriteria(nonuts_vegetar), 0.0001);
    assertEquals(0, nonuts.foodCriteria(nonuts_vegetar), 0.0001);
    
    assertEquals(matriceCout[0][1], nonuts_vegetar.foodCriteria(nonuts), 0.0001);
    assertEquals(matriceCout[0][1], vegetar.foodCriteria(nonuts), 0.0001);
    assertEquals(matriceCout[0][1], nonuts.foodCriteria(vegetar), 0.0001);


}

@Test
public void testHistoryCriteria(){
    HashMap<Criterion,String> criteriaOther=new HashMap<>();
    criteriaOther.put(Criterion.GUEST_ANIMAL_ALLERGY, "yes");
    criteriaOther.put(Criterion.HOST_HAS_ANIMAL, "no");
    // criteriaOther.put(Criterion.GUEST_FOOD, "");
    criteriaOther.put(Criterion.HOST_FOOD, "");
    criteriaOther.put(Criterion.HOBBIES, "");
    criteriaOther.put(Criterion.GENDER, "male");
    criteriaOther.put(Criterion.PAIR_GENDER, "");
    criteriaOther.put(Criterion.HISTORY, "other");

    HashMap<Criterion,String> criteriaSame=new HashMap<>();
    criteriaSame.put(Criterion.GUEST_ANIMAL_ALLERGY, "yes");
    criteriaSame.put(Criterion.HOST_HAS_ANIMAL, "no");
    // criteriaSame.put(Criterion.GUEST_FOOD, "");
    criteriaSame.put(Criterion.HOST_FOOD, "");
    criteriaSame.put(Criterion.HOBBIES, "");
    criteriaSame.put(Criterion.GENDER, "male");
    criteriaSame.put(Criterion.PAIR_GENDER, "");
    criteriaSame.put(Criterion.HISTORY, "same");

    HashMap<Criterion,String> criteriaWhoCares=new HashMap<>();
    criteriaWhoCares.put(Criterion.GUEST_ANIMAL_ALLERGY, "yes");
    criteriaWhoCares.put(Criterion.HOST_HAS_ANIMAL, "no");
    // criteriaWhoCares.put(Criterion.GUEST_FOOD, "");
    criteriaWhoCares.put(Criterion.HOST_FOOD, "");
    criteriaWhoCares.put(Criterion.HOBBIES, "");
    criteriaWhoCares.put(Criterion.GENDER, "male");
    criteriaWhoCares.put(Criterion.PAIR_GENDER, "");
    criteriaWhoCares.put(Criterion.HISTORY, "");


    Adolescent other1=new Adolescent("null", "null", "male", null, "FR", criteriaOther);
    Adolescent other2=new Adolescent("null", "null", "male", null, "FR", criteriaOther);
    System.out.println(other1.getCriteria().get(Criterion.HISTORY));
    other1.setLastPaired(other2);
    other2.setLastPaired(other1);
    System.out.println(other1.getCriteria().get(Criterion.HISTORY));
    assertEquals(2*matriceCout[0][1], other1.historyCriteria(other2), 0.0001);

    Adolescent same1=new Adolescent(null, null, "male", null, "ES", criteriaSame);
    Adolescent whoCares1=new Adolescent(null, null, "male", null, "ES", criteriaWhoCares);
    same1.setLastPaired(whoCares1);
    whoCares1.setLastPaired(same1);
    assertEquals(matriceCout[4][0], same1.historyCriteria(whoCares1), 0.0001);
    same1.setLastPaired(null);
    whoCares1.setLastPaired(null);
    assertEquals(matriceCout[4][0], same1.historyCriteria(whoCares1), 0.0001);


}

 @Test
 public void testCompabilityScore() {
 assertEquals(3, ado1.compatibilityScore(ado2),0.0001);
 assertEquals(3, ado2.compatibilityScore(ado1),0.0001);
 assertEquals(104, ado3.compatibilityScore(ado2),0.0001);
 assertEquals(4, frenchie.compatibilityScore(ado2),0.0001); 
 }

 // ado1 - ado2 / 0 hobbies en commun / Pair gender -2 / age 0
 // frenchie - ado1 / 0 hobbies en commun / Pair gender -1 / age 0
 // ado2 - ado3 / -0,5 car 1 hobby en commun / Pair gender -1 / age 0


 @Test
 public void testEquals() {
 assertFalse(ado1.equals(ado3));
 assertTrue(ado2.equals(ado2Bis));
 }
}


