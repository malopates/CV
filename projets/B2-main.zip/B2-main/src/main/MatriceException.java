package main;

public class MatriceException extends Exception{
    public MatriceException(String message){
        super(message);
    }
}
