package main;

import java.io.Serializable;
import java.util.HashMap;

import extensionPOO.AdolescentPlus;

public class Pair implements Comparable<Pair>, Serializable{
    private double score;
    protected Adolescent guest;
    protected Adolescent host;
 
    //Uniquement pour la partie IHM (aurait pu être implémentée pour la POO)
    private HashMap<String, Double> valeurCriterion;

    public Pair(double score, Adolescent guest, Adolescent host){
        this.score=score;
        this.guest=guest;
        this.guest.setLastPaired(host);
        this.host=host;
        this.host.setLastPaired(guest);
    }

    //Uniquement pour l'IHM
    public Pair(AdolescentPlus guestPlus, AdolescentPlus hostPlus){
        this.guest=guestPlus;
        this.host=hostPlus;
        this.valeurCriterion=guestPlus.compatibilityScore(hostPlus);
        // System.out.println("Les valeurs des criterions de la paire " + this.valeurCriterion);
        this.score=this.valeurCriterion.get("TOTAL");
    }
    
    public Pair(Adolescent guest, Adolescent host){
        this(guest.compatibilityScore(host), guest, host);
        
    }

    public Adolescent getHost() {
        return host;
    }
    public Adolescent getGuest() {
        return guest;
    }
    public double getScore() {
        return score;
        
    }

    //Uniquement pour l'IHM
    public HashMap<String, Double> getValeurCriterion() {
        return valeurCriterion;
    }

    // public static double[][] createCostMatrix(){

    // }
    public int compareTo(Pair othePair){
        return this.guest.compareTo(othePair.guest);
    }

    public String toStringNoScore(){//sans le score, pour IHM
        return this.guest.toStringName()+"<--->"+this.host.toStringName();
    }
    public String toString(){
        return this.guest.toStringName()+"<--"+this.score+"-->"+this.host.toStringName();
    }

}