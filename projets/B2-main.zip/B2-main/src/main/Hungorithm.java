package main;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;

// import fr.ulille.butinfo.sae202.graphes.*;
import main.exceptions.MatriceException;

public class Hungorithm {
    private double[][] pairMatrix;    
    private ArrayList<Integer> coveredCols;//Utilisées pour marquer les lignes ou colonnes contenant des zeros sélections
    private ArrayList<Integer> coveredLines;

    private ArrayList<Integer> colsBarrees;//Utilisées pour les "étapes A et B" de la vidéo 
    private ArrayList<Integer> lignesBarres;

    //Pour les étapes A et B
    private ArrayList<Integer> colsMarquees;
    private ArrayList<Integer> linesMarquees;

    private int nbZeroSelec;

    private ArrayList<Double> casesNonBarrees;

    // private GrapheNonOrienteValue<Adolescent> graphe=new GrapheNonOrienteValue<>();
    

    // private CalculAffectation c;
    // private Arete a;

    private int[][] zeroMatrix; 
    //1 est 0 sélectionné dans la vidéo
    //2 est 0 barré dans la vidéo
    //3 est épargné par les lignes barrées dans la vidéo
    //4 est l'intersection de deux lignes dans la vidéo

    public Hungorithm(double[][] pairMatrix) throws MatriceException{
        this.pairMatrix=pairMatrix;
        if(!this.validMatrix()){throw new MatriceException("Matrice non carrée !");}
        this.zeroMatrix=new int[pairMatrix.length][pairMatrix[0].length];

        this.nbZeroSelec=0;

        this.colsBarrees=new ArrayList<>();
        this.lignesBarres=new ArrayList<>();

        this.linesMarquees=new ArrayList<>();
        this.colsMarquees=new ArrayList<>();

        this.coveredCols=new ArrayList<>();
        this.coveredLines=new ArrayList<>();

        this.casesNonBarrees=new ArrayList<>();   

    }

    // public static ArrayList<Pair> hungorithmProf(ArrayList<Adolescent> guests, ArrayList<Adolescent> host){
    //     //Création du graphe
    // }


    private void initialMatrixReduction(){
        this.normalizeLines();
        this.normalizeCols();
    }

    private void normalizeLines(){
        double min;
        for(int ligne=0; ligne<this.pairMatrix.length; ligne++){
            min=this.pairMatrix[ligne][0];
            for(int col=0; col<pairMatrix[0].length; col++){
                if(this.pairMatrix[ligne][col]<min){
                    min=pairMatrix[ligne][col];
                }
            }

            for(int col=0; col<pairMatrix[0].length; col++){
                pairMatrix[ligne][col]-=min;
            }
        }
    }

    private void normalizeCols(){
        double min;
        for(int col=0; col<this.pairMatrix[0].length; col++){
            min=this.pairMatrix[0][col];
            for(int ligne=0; ligne<this.pairMatrix.length; ligne++){
                if(this.pairMatrix[ligne][col]<min){
                    min=this.pairMatrix[ligne][col];
                }
            }

            for(int ligne=0; ligne<this.pairMatrix.length; ligne++){
                this.pairMatrix[ligne][col]-=min;
            }
        }
    }


    public boolean validMatrix(){//Vérifie que la matrice est carrée
        if(this.pairMatrix!=null){
            return this.pairMatrix.length==this.pairMatrix[0].length;
        }
        return false;
    }

    public void selection0(){

        this.coveredCols.clear();
        this.coveredLines.clear();
        this.nbZeroSelec = 0;

        HashMap<Integer, Integer> zeroParLigne=new HashMap<>();


        int nbZeroLigne;

        for(int ligne=0; ligne<this.pairMatrix.length; ligne++){
            nbZeroLigne=0;
            for(int col=0; col<this.pairMatrix[0].length; col++){
                if(this.pairMatrix[ligne][col]==0.0){
                    nbZeroLigne++;
                }
            }
            zeroParLigne.put(Integer.valueOf(ligne), Integer.valueOf(nbZeroLigne));
        }

        ArrayList<Integer> lignesTriees = new ArrayList<>(zeroParLigne.keySet());
        lignesTriees.sort(Comparator.comparingInt(zeroParLigne::get));

        // for(int ligne=0; ligne<this.pairMatrix.length; ligne++){
        for(int ligne : lignesTriees){
            for(int col=0; col<this.pairMatrix[0].length; col++){
                if(this.pairMatrix[ligne][col]==0.0){
                    if((!(this.coveredLines.contains(ligne)))&&(!(this.coveredCols.contains(col)))){
                        this.coveredCols.add(col);
                        this.coveredLines.add(ligne);
                        this.zeroMatrix[ligne][col]=1;
                        this.nbZeroSelec++;
                        // break;
                    }//Dans la vidéo, il est préconisé de commencer par la ligne ayant le moins de 0

                }
            }
        }
    }

    public void selection0barre(){
        for(int ligne=0; ligne<this.pairMatrix.length; ligne++){
            for(int col=0; col<this.pairMatrix[0].length; col++){
                if((this.pairMatrix[ligne][col]==0)&&(this.zeroMatrix[ligne][col]!=1)){
                    this.zeroMatrix[ligne][col]=2;
                }
            }
        }
    }

    public void stepA(){
        for(int cpt=0; cpt<this.pairMatrix.length; cpt++){
            if(!this.coveredLines.contains(cpt)){
                if(!this.linesMarquees.contains(cpt)){
                    this.linesMarquees.add(cpt);
                System.out.println("stepA: ajout ligne " + cpt);
                }
            }
        }
    }

    public boolean stepB(){
        boolean aModifie=false;
        for(Integer ligne: this.linesMarquees){
            for(int col=0; col<this.pairMatrix[0].length; col++){
                if(this.zeroMatrix[ligne][col]==2){
                    if(!this.colsMarquees.contains(col)){
                        this.colsMarquees.add(col);
                        aModifie=true;
                    }
                }
            }
        }
        return aModifie;

    }

    public boolean stepC(){
        boolean aModifie=false;
        for(int ligne=0; ligne<this.pairMatrix.length; ligne++){
            for (Integer col : this.colsMarquees) { //Un while serait plus efficace
                if(this.zeroMatrix[ligne][col]==1){
                    if(!this.linesMarquees.contains(ligne)){
                        this.linesMarquees.add(ligne);
                        aModifie=true;
                    }
                }
            }
        }
        return aModifie;
    }

    public void barrerLignesEtCols(){

        this.lignesBarres.clear();
        this.colsBarrees.clear();

        for(int cpt=0; cpt<this.pairMatrix.length; cpt++){
            if(!this.linesMarquees.contains(cpt)){this.lignesBarres.add(cpt);}
            if(this.colsMarquees.contains(cpt)){this.colsBarrees.add(cpt);}//addAll
        }
        System.out.println("Lines barrees : " + this.lignesBarres);
        System.out.println("Cols barrees : " + this.colsBarrees);
    }

    public void majMatrixZero(){
        this.casesNonBarrees.clear();
        for(int ligne=0; ligne<this.zeroMatrix.length; ligne++){
            for(int col=0; col<this.zeroMatrix[0].length; col++){
                // if(zeroMatrix[ligne][col]==0){
                    if(!((this.lignesBarres.contains(ligne))||(this.colsBarrees.contains(col)))){
                        zeroMatrix[ligne][col]=3;//Epargnees par les barres
                        this.casesNonBarrees.add(this.pairMatrix[ligne][col]);
                    }else{
                        if ((this.lignesBarres.contains(ligne))&&(this.colsBarrees.contains(col))){
                            zeroMatrix[ligne][col]=4;//A l'intersection de barres
                        }
                    }
                // }
                    
            }
        }
        System.out.println("Nombre de cases non barrées : " + this.casesNonBarrees.size());
    }

    public double getMinNonBarre(){
        return Collections.min(this.casesNonBarrees);
    }

    public void majMatrix(double min){
        for(int ligne=0; ligne<this.zeroMatrix.length; ligne++){
            for(int col=0; col<this.zeroMatrix[0].length; col++){
                if(this.zeroMatrix[ligne][col]==4){
                    this.pairMatrix[ligne][col]+=min;
                }else 
                if(this.zeroMatrix[ligne][col]==3){
                    this.pairMatrix[ligne][col]-=min;
                }
            }
        }
    }

    private ArrayList<Integer[]> getOptimumCoord(){
        ArrayList<Integer[]> res=new ArrayList<>();
        //Les listes sont normalement ordonnées car on les incrémente au même moment et on n'enlève jamais de termes
        for(int cpt=0; cpt<this.pairMatrix.length; cpt++){
            res.add(new Integer[]{this.coveredLines.get(cpt),this.coveredCols.get(cpt)});
        }
        return res;
    }

    private void goToInitialPosition(){

        this.nbZeroSelec=0;

        this.colsBarrees=new ArrayList<>();
        this.lignesBarres=new ArrayList<>();

        this.linesMarquees=new ArrayList<>();
        this.colsMarquees=new ArrayList<>();

        this.coveredCols=new ArrayList<>();
        this.coveredLines=new ArrayList<>();

        this.casesNonBarrees=new ArrayList<>();    
    
    }

    public static ArrayList<Integer[]> hungorithm(double[][] pairMatrix) throws MatriceException{
        Hungorithm hg=new Hungorithm(pairMatrix);
        //Initialisation

        System.out.println("Matrice avant initialisation : ");
        System.out.println(hg.printMatrix(hg.pairMatrix));

        hg.initialMatrixReduction();
        
        System.out.println("Matrice initialisée : ");
        System.out.println(hg.printMatrix(hg.pairMatrix));
        
        //Boucle
        while (hg.nbZeroSelec<hg.pairMatrix.length) {//Tant que la matrice n'est pas optimale
        
        hg.goToInitialPosition(); //Reset des listes et du nombre de zéro
        hg.selection0(); //"Encadrement" des 0
        
        System.out.println("Lignes couvertes : "+hg.coveredLines+"\nColonnes couvertes : "+hg.coveredCols);
        
            if(hg.nbZeroSelec<hg.pairMatrix.length){
                System.out.println(hg.nbZeroSelec+", objectif : "+hg.pairMatrix.length);
                hg.selection0barre(); //Barrer les 0 dans les croix formées par les 0 encadrés
                hg.stepA(); 

                boolean test;
                do {
                    test = hg.stepB();
                    test = hg.stepC() || test;
                } while (test);

                hg.barrerLignesEtCols();
                hg.majMatrixZero();
                System.out.println(hg.printMatrix(hg.zeroMatrix));
                System.out.println(hg.casesNonBarrees);
                hg.majMatrix(hg.getMinNonBarre());
            }
        }    
        System.out.println("Final : "+hg.nbZeroSelec+", objectif : "+hg.pairMatrix.length);

        return hg.getOptimumCoord();

    }


    //Méthodes outils
    private String printMatrix(double[][] matrix){
        if(matrix==null){return "null";}
        StringBuilder sb=new StringBuilder();
        String cell;
        for(int lig=0; lig<matrix.length; lig++){
            for(int col=0; col<matrix[0].length; col++){
                cell="";
                if((matrix[lig][col]>9)||(matrix[lig][col]<-9)){
                    cell="|"+matrix[lig][col]+"|";
                }else{
                    cell="| "+matrix[lig][col]+"|";
                }
                sb.append(cell);

            }
            sb.append("\n");
            for(int cpt=0;cpt<matrix.length*6; cpt++){
                sb.append("-");
            }
            sb.append('\n');
        }
        return sb.toString();
    }

    private String printMatrix(int[][] matrix){
        StringBuilder sb=new StringBuilder();
        for(int ligne=0; ligne<matrix.length; ligne++){
            sb.append("|");
            for(int col=0; col<matrix[0].length; col++){
                sb.append(""+matrix[ligne][col]);
                sb.append("|");
            }
            sb.append('\n');
            for(int cpt=0;cpt<matrix.length+6; cpt++){
                sb.append("-");
            }
            sb.append('\n');
        }
        return sb.toString();
    }

    // Main de débug
    public static void main(String[] args){
        double[][] pairing=new double[][]{{17,15,9,5,12},{16,16,10,5,10},{12,15,14,11,5},{4,8,14,17,13},{13,9,8,12,17}};
        double[][] pairing2=new double[][]{{70,40,20,55},{65,60,45,90},{30,45,50,75},{25,30,55,40}};

        Main testMain=new Main();
        ImportExport testIE=new ImportExport();

        ArrayList<Adolescent> guests=testIE.importAdolescents("10guests.csv");
        System.out.println(guests);
        ArrayList<Adolescent> hosts=testIE.importAdolescents("10hosts.csv");
        System.out.println(hosts);

        double[][] pairingTest=testMain.getTheScoreMatrix(testMain.makeAPairingMatrix(guests,hosts));
        double[][] testMatrix = new double[10][10];
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                testMatrix[i][j] = (i == j) ? 0 : 1; // Identity matrix (optimal assignment on diagonal)
            }
        }

        try{

            Hungorithm hg=new Hungorithm(pairing);

            ArrayList<Integer[]> res=Hungorithm.hungorithm(testMatrix);
            
            for(Integer[] cell : res){
                System.out.print("Ligne : "+cell[0]);
                System.out.print("Colonne : "+cell[1]);
                System.out.print("\n");
            }

            // System.out.println("Pré-setup");
            // hg.printMatrix(hg.pairMatrix);
            // hg.initialMatrixReduction();;
            // System.out.println("Post-setup");
            // hg.printMatrix(hg.pairMatrix);
            // hg.selection0();
            // System.out.println("Lignes à couvrir : "+hg.coveredLines.toString());
            // System.out.println("Colonnes à couvrir : "+hg.coveredCols.toString());
            // System.out.println("Matrice des 0 : ");
            // hg.printMatrix(hg.zeroMatrix);
            // System.out.println("Barrage des 0 non sélectionnés : ");
            // hg.selection0barre();
            // hg.printMatrix(hg.zeroMatrix);
            // hg.stepA();
            // System.out.println(hg.linesMarquees);
            // hg.stepB();
            // System.out.println(hg.colsMarquees)  ;
            // hg.stepC();
            // System.out.println(hg.linesMarquees);
            // hg.barrerLignesEtCols();
            // System.out.println(hg.lignesBarres);
            // System.out.println(hg.colsBarrees);
            // hg.majMatrixZero();
            // hg.printMatrix(hg.zeroMatrix);
            // hg.majMatrix(hg.getMinNonBarre());
            // System.out.println(hg.printMatrix(hg.pairMatrix));
        }catch(MatriceException ex){
            System.out.println(ex.getMessage());
        }
    }


    //TODO Idées chronophages :
    // private class Cell{ //Permet d'utiliser des pointeurs dans les listes
    //     private double score;
    //     private boolean nulle;
    //     private boolean selectionnee;
    //     private boolean barre;
    // }
    // // * Deux tableaux ? Un "lignes", un "colonnes"
    // private Cell Cell(double score, boolean nulle, boolean selectionnee, boolean barre){
    //     Cell c=new Cell();
    //     c.score=score;
    //     c.nulle=nulle;
    //     c.selectionnee=selectionnee;
    //     c.barre=barre;
    //     return c;
    // }

    // private Cell[][] convertIntoCells(double[][] pairMatrix){
    //     Cell[][] tab=new Cell[pairMatrix.length][pairMatrix[0].length];
    //     for(int ligne=0; ligne<pairMatrix.length; ligne++){
    //         for(int col=0; col<pairMatrix[0].length; col++){
    //             tab[ligne][col]=Cell(pairMatrix[ligne][col], false, false, false);
    //         }
    //     }
    //     return tab;
    // }

}

