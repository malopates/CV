package main;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

import extensionPOO.AdolescentPlus;
import main.exceptions.MatriceException;

public class Main {
    private Historique histor;
    
    public Main(){

    }

    /**
     * Va créer une matrice de paires, dont les lignes sont les guests et les hosts les colonnes. On exÃ©cutera ensuite l'algorithme Hongrois dessus pour trouver
     * les appariements Ã  couts minimaux.
     * 
     * @param guests Une liste d'adolescents qui cherchent à être accueilis.
     * 
     * @param hosts Une liste d'adolescents qui se proposent comme hôtes.
     */
    public Pair[][] makeAPairingMatrix(ArrayList<Adolescent> guestsList, ArrayList<Adolescent> hostsList){
        
        Adolescent[] vide=new Adolescent[0];
        Adolescent[] guests=guestsList.toArray(vide);
        Adolescent[] hosts=hostsList.toArray(vide);
        // System.out.println(guestsList.get(0).getClass());
        // System.out.println(hostsList.get(0).getClass());

        Pair[][] pairingMatrix=new Pair[guests.length][hosts.length];

        int ligne,colonne;

        ligne=0;
        
        for(Adolescent guest: guests){
        colonne=0;
        for(Adolescent host: hosts){
            pairingMatrix[ligne][colonne]=new Pair(guest, host);
            colonne++;
        }
        ligne++;
        }


        return pairingMatrix;
    }

    public Pair[][] makeAPairingMatrixPlus(ArrayList<AdolescentPlus> guestsList, ArrayList<AdolescentPlus> hostsList){
        
        AdolescentPlus[] vide=new AdolescentPlus[0];
        AdolescentPlus[] guests=guestsList.toArray(vide);
        AdolescentPlus[] hosts=hostsList.toArray(vide);
        // System.out.println(guestsList.get(0).getClass());
        // System.out.println(hostsList.get(0).getClass());

        Pair[][] pairingMatrix=new Pair[guests.length][hosts.length];

        int ligne,colonne;

        ligne=0;
        
        for(AdolescentPlus guest: guests){
        colonne=0;
        for(AdolescentPlus host: hosts){
            pairingMatrix[ligne][colonne]=new Pair(guest, host);
            colonne++;
        }
        ligne++;
        }


        return pairingMatrix;
    }

    // public PairPlus[][] makeAPairingMatrixPlus(ArrayList<AdolescentPlus> guestsList, ArrayList<AdolescentPlus> hostsList){
        
    //     AdolescentPlus[] vide=new AdolescentPlus[0];
    //     AdolescentPlus[] guests=guestsList.toArray(vide);
    //     AdolescentPlus[] hosts=hostsList.toArray(vide);
        
    //     PairPlus[][] pairingMatrix=new PairPlus[guests.length][hosts.length];

    //     int ligne,colonne;

    //     ligne=0;
    //     for(AdolescentPlus guest: guests){
    //         colonne=0;
    //         for(AdolescentPlus host: hosts){
    //             pairingMatrix[ligne][colonne]=new PairPlus(guest, host);
    //             colonne++;
    //         }
    //         ligne++;
    //     }


    //     return pairingMatrix;
    // }

    public double[][] getTheScoreMatrix(Pair[][] pairingMatrix){ // Permet d'avoir une matrice ne contenant que les scores, ce qui pourrait s'avÃ©rer utile Ã  l'exécution de l'algorithme Hongrois.
        double[][] scoreMatrix=new double[pairingMatrix.length][pairingMatrix[0].length];
        
        for(int lig=0; lig<scoreMatrix.length; lig++){
            for(int col=0; col<scoreMatrix[0].length; col++){
                scoreMatrix[lig][col]=pairingMatrix[lig][col].getScore();
            }
        }

        return scoreMatrix;
    }

    public ArrayList<Pair> removeBFFs(ArrayList<Adolescent> guests, ArrayList<Adolescent> hosts){
        ArrayList<Pair> initialPairs=new ArrayList<>();
        //TODO : Trouver une alternative
        ArrayList<Adolescent> guestsToBeRemoved=new ArrayList<>();

        for(Adolescent guest: guests){
            if(guest.getHistory().equals("same")){
                //VÃ©rifier que lastPaired est dans host est potentiellement inutile
                if((hosts.contains(guest.getLastPaired()))&&(guest.getLastPaired().getHistory().equals("same"))){ //Si l'host existe et qu'il veut aussi le other
                    initialPairs.add(new Pair(guest, guest.getLastPaired()));//On garde les pointeurs TODO réfléchir au score
                    hosts.remove(guest.getLastPaired());
                    guestsToBeRemoved.add(guest);
                }
            }
        }
        guests.removeAll(guestsToBeRemoved);//Plutôt moche, mais seul moyen de ne pas violer l'intÃ©gritÃ© du forEach
        return initialPairs;
    }

    public ArrayList<Pair> createPairingList(ArrayList<Adolescent> guests, ArrayList<Adolescent> hosts){
        ArrayList<Pair> pairingList=removeBFFs(guests, hosts);


        
        Pair[][] pairingMatrix=makeAPairingMatrix(guests, hosts);
        double[][] scoreMatrix=getTheScoreMatrix(pairingMatrix);
        // ArrayList<Pair> optimalPairs=hungorithm(scoreMatrix);

        // pairingList.addAll(optimalPairs);
        Collections.sort(pairingList);

        return pairingList;
    }
  
    public void affichageMatrice(double[][] matrix){
        String affichage="";
        for(int lig=0; lig<matrix.length; lig++){
            for(int col=0; col<matrix[0].length; col++){
                affichage+=matrix[lig][col]+" ";
            }
            affichage+="\n";
        }
        System.out.println(affichage);
    }

    public static void main(String[] args){
        // Pour vérifier le bon fonctionnement de la Serialization, il est possible de supprimer le fichier historique.ser, mais il faut faire un run du main avec un save avant de load.
        // Initialisation
        Pair[][] pairMatrix;
        double[][] matrixScore;
        ArrayList<Integer[]> resultHungorithm = new ArrayList<>();
        ArrayList<Pair> pairs = new ArrayList<>();
        Pairing pairing;
        ArrayList<Pairing> listPairing = new ArrayList<>();


        // Import des Adolescents
        ImportExport importExport = new ImportExport();
        ArrayList<Adolescent> hosts = importExport.importAdolescents("hosts.csv");
        ArrayList<Adolescent> guests = importExport.importAdolescents("guests.csv");   
       
        // Affichage
        System.out.println();
        System.out.println("Voici les hosts : " + hosts);
        System.out.println();
        System.out.println("Voici les guests : " + guests);

        // Mise en place de l'algorithme Hongrois
        pairMatrix = new Main().makeAPairingMatrix(guests, hosts);
        matrixScore = new Main().getTheScoreMatrix(pairMatrix);
        
        // Algorithme Hongrois
        try {
            resultHungorithm = Hungorithm.hungorithm(matrixScore);
           } catch (MatriceException e) {
                e.printStackTrace();
        }

        // Récupération des résultats
        for (Integer[] lig: resultHungorithm) {
            pairs.add(pairMatrix[lig[0]][lig[1]]);
        }

        // Création du Pairing
        pairing = new Pairing(LocalDate.now(), pairs.get(0).guest.getBIRTHCOUNTRY(), pairs.get(0).host.getBIRTHCOUNTRY(), pairs);

        // Affichage du pairing
        System.out.println();
        System.out.println(pairing);

        // Choix de l'action
        System.out.println();
        System.out.print("Voulez vous load ou save l'historique ? (1 pour load, 2 pour save) : ");
        Scanner scanner = new Scanner(System.in);
        int choice = Integer.valueOf(scanner.nextLine());
        scanner.close();

        // Load ou Save
        Historique historique;
        if (choice == 1) {
            historique = Historique.loadHistoric();
        } else {
            System.err.println("ici");
            historique = new Historique();
            listPairing.add(pairing);
            historique.historic.put(pairing.getPairingDate().getYear(), listPairing);
            historique.saveHistoric();
        }

        System.out.println(historique.historic);
        
    }

    

}

