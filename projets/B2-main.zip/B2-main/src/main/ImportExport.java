package main;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import javax.print.DocFlavor.INPUT_STREAM;

import main.enums.CSVColumns;
import main.enums.Criterion;
import main.exceptions.ExceptionCritere;
import main.exceptions.ExceptionCritereBoolean;
import main.exceptions.ExceptionCritereGender;
import main.exceptions.InvalidStructureException;

public class ImportExport {
    // — [poo]export d’un résultat sous format csv
    private static final String PATH=System.getProperty("user.dir")+File.separator+"res"+File.separator;
    private final String SAVEPATH=ImportExport.PATH+"saves"+File.separator;
    private final String IMPORTPATH=ImportExport.PATH+"imports"+File.separator;

    private final ArrayList<String> COLUMNSPRESET=CSVColumns.getColumnsPreset();
    private final int COLUMNNUMBER=COLUMNSPRESET.size();
    public static final String CSVDELIMITER=";";
    private static final int NBCOLUMNCSV=CSVColumns.getColumnsPreset().size();

    private static boolean defaultExist = false;
    private static HashMap<Criterion, String> defaultValuesFromCSV= ImportExport.importDefaultValues();

    public static HashMap<String,Double> importWeightValues() {
        HashMap<String,Double> weightValues = new HashMap<>();
        try {
            File f = new File(PATH + "weight.csv");
            Scanner scanner = new Scanner(f);
            scanner.nextLine();
            weightValues.put("HOBBIES", (-1) * Double.valueOf(scanner.nextLine().split(CSVDELIMITER)[1]));
            weightValues.put("HISTORY", Double.valueOf(scanner.nextLine().split(CSVDELIMITER)[1]));
            weightValues.put("GENDER", Double.valueOf(scanner.nextLine().split(CSVDELIMITER)[1]));
            weightValues.put("FOOD", Double.valueOf(scanner.nextLine().split(CSVDELIMITER)[1]));
            weightValues.put("ALLERGIES", Double.valueOf(scanner.nextLine().split(CSVDELIMITER)[1]));

            scanner.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        System.out.println("Voila le resultat "+weightValues);
        return weightValues;
    }

    private static HashMap<Criterion, String> importDefaultValues() { // importe correctement le csv MAIS ne fais rien du header pour le moment
        File f;
        HashMap<Criterion,String> tmpHashMap = new HashMap<>();
        if (new File(PATH + "default.csv").exists()) {
            f = new File(PATH + "default.csv");
            ImportExport.defaultExist = true;

            try (Scanner scanner = new Scanner(f);) {
                scanner.nextLine();
                // for (String s: header) System.out.println(s);
                while (scanner.hasNextLine()) {
                    String[] tmp = scanner.nextLine().split(CSVDELIMITER);
                    // for (String s: tmp) System.out.println(s);
                    tmpHashMap.put(Criterion.valueOf(tmp[0]), tmp[1].replaceAll("\"", ""));
                } 
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("fuck");
            System.out.println(ImportExport.defaultExist);
        }
        return tmpHashMap;
    }


    public ArrayList<Adolescent> importAdolescents(String fileName){
        
        String filePath=this.IMPORTPATH+fileName;

        ArrayList<Adolescent> adolescents=new ArrayList<>();


        String[] ligne;

        String foreName,name,country,birthDate;


        try {
            Validation.checkFile(filePath, NBCOLUMNCSV, CSVColumns.getColumnsPreset());

            Scanner scan=new Scanner(new File(filePath));            

            String[] header=this.getHeader(scan);

            int[] headerIdx=this.headerIdx(header);
    
            while (scan.hasNextLine()) {
                HashMap<Criterion, String> criteria=new HashMap<>();
                ligne=scan.nextLine().split(ImportExport.CSVDELIMITER,COLUMNNUMBER);//Limit=nbCol pour le forcer à fetch le denier

                foreName=ligne[headerIdx[0]];
                name=ligne[headerIdx[1]];
                country=ligne[headerIdx[2]];
                birthDate=ligne[headerIdx[3]];
                for(Criterion c : Criterion.values()){
                    criteria.put(c, ligne[headerIdx[c.ordinal()+4]]);
                }
                // System.out.println(criteria.get(Criterion.GENDER));
                if(this.logicalCriteria(criteria)){//isCoherent => Laisser logicalCriteria sinon on a un problème
                    adolescents.add(new Adolescent(name, foreName, criteria.get(Criterion.GENDER), birthDate, country, criteria));
                }//Sont passés les adolescents inCohérents !
                // System.out.println(criteria.get(Criterion.GENDER));
            }
            scan.close();

        } catch (FileNotFoundException ex) {
            System.out.println(ex.getMessage());
        } catch (InvalidStructureException ex){
            System.out.println(ex.getMessage());
        }

        return adolescents; 
    }

    public void exportPairing(Pairing pairing){
        String name=pairing.getGuestCountry()+"-"+pairing.getHostCountry()+"-"+pairing.getPairingDate().getYear();
        String ligne="";
        
        File saveFile=new File(this.SAVEPATH+name+".csv");
        try{

            BufferedWriter bw=new BufferedWriter(new FileWriter(saveFile));  
            bw.write("Guest"+ImportExport.CSVDELIMITER+"Score de compatibilite"+ImportExport.CSVDELIMITER+"Host");
            bw.newLine();
            
            //TODO Gérer le cas où le fichier existe => write()!=append() ?
            for(Pair p: pairing.getPairs()){
                ligne=p.getGuest().toStringName()+ImportExport.CSVDELIMITER+p.getScore()+ImportExport.CSVDELIMITER+p.getHost().toStringName();
                bw.write(ligne);
                bw.newLine();
            }
            bw.close();

        }catch(IOException ex){
            System.out.println(ex.getMessage());
        }
    }

    private String[] getHeader(Scanner scan){
        String[] header=null;
        if(scan.hasNextLine()){
            header=(scan.nextLine().split(ImportExport.CSVDELIMITER));
        }
        return header;
    }

    private int[] headerIdx(String[] header){//Objectif : avoir l'indice des c
        int[] columnIdx=new int[header.length];
        int cpt=0;
        for(String colName : COLUMNSPRESET){
            // if(COLUMNSPRESET.indexOf(colName)!=-1){// Ajouter à Validation en tant que InvalidStructure de colName not Among => Plus nécessaire car géré autre part 
                columnIdx[cpt]=COLUMNSPRESET.indexOf(colName);
            // }
            cpt++;
        }
        return columnIdx;
    }

    /**
    // Vérifie la cohérence d'un adolescent, e.g si toutes les valeurs entrées soit cohérent selon le type (boolean) ou cohérent selon le genre de valeurs attendues , quand c'est possible.
     * 
     * @return True si l'adolescent est cohérent, False sinon
     */


    public boolean logicalCriteria(HashMap<Criterion, String> criteria){//Vérifie la cohérence de la valeur : 1) "yes" ou "no" pour les booléens 2) un des valeurs connues pour les critères à réponses limitées
        //private 
        //répétition + pas de control de saisie mais rajout si le temps.
        boolean logical=true;
        String value;

        for (Criterion c: criteria.keySet()){
            value=criteria.get(c);
            try{
                this.logicalCriterion(c, value);
            }
            catch(ExceptionCritere e){
                if (ImportExport.defaultExist)
                    criteria.put(c, ImportExport.defaultValuesFromCSV.get(c));
                else {
                    System.out.print("replace values of " + c + " with : ");   
                    Scanner scanner = new Scanner(System.in);
                    criteria.put(c, scanner.nextLine());
                    scanner.close();
                }
            }
            catch(ExceptionCritereBoolean e){
                System.out.println(ImportExport.defaultExist);

                if (ImportExport.defaultExist)
                // System.out.println(e.getMessage());                
                    criteria.put(c, ImportExport.defaultValuesFromCSV.get(c));
                else {

                    System.out.print("replace values of " + c + " with : ");   
                    Scanner scanner = new Scanner(System.in);
                    criteria.put(c, scanner.nextLine());
                    scanner.close();
                }

            }
            catch(ExceptionCritereGender e){
                if (ImportExport.defaultExist)
                    criteria.put(c, ImportExport.defaultValuesFromCSV.get(c));
                // criteria.put(c,"other");
                else {
                    System.out.print("replace values of " + c + " with : ");   
                    Scanner scanner = new Scanner(System.in);
                    criteria.put(c, scanner.nextLine());
                    scanner.close();
                }

            } 
        }
    
        return logical; //True si c'est bon ou corrigé / False si c'est impossible à corriger ET DONC l'adolescent est viré à l'import
        //TODO : A deplacer lors de l'écriture de l'import
        //TODO : Exception critiques
    }

 public boolean logicalCriterion(Criterion c, String value) throws ExceptionCritere,ExceptionCritereBoolean,ExceptionCritereGender{
        boolean logical=true;
        if (c.getTYPE()=='B'){
            if(!(ToolBox.isAmong(value,"yes","no"))){
                throw new ExceptionCritereBoolean("Booléen incorrect \""+value+"\": Adolescent à retirer");
            }
        
        } else if (c==Criterion.GENDER){
            if(!(ToolBox.isAmong(value, "male","female","other"))){
                throw new ExceptionCritereGender("Critère GENDER incorrect \""+value+"\"");
            }
        
        }else if (c==Criterion.PAIR_GENDER){ //Null empêche de fusionner avec la partie supérieure
            if(!(ToolBox.isAmong(value, "male","female","other",""))){
                throw new ExceptionCritere("Critère PAIR GENDER incorrect \""+value+"\"")
                ;}
        
        }else if (c==Criterion.HISTORY){
            if(!(ToolBox.isAmong(value, "other","same",""))){
                throw new ExceptionCritere("Critère HISTORY incorrect\""+value+"\"");
            }
        
        }else if((c==Criterion.GUEST_FOOD_CONSTRAINT)||(c==Criterion.HOST_FOOD)){
            if(!(ToolBox.isAmong(value, "nonuts","vegetarian","nonuts,vegetarian","vegetarian,nonuts",""))){ //TODO split
                throw new ExceptionCritere("Critère GUEST_FOOD ou HOST_FOOD incorrect\""+value+"\"");
            }
        }
        return logical;
    }


    public static void main(String[] args){

        // System.out.println(PATH);
        // System.out.println("D:\\Tri\\BUT Info\\SAE\\SAE POO\\B2\\res\\imports\\guests.csv");
        ImportExport impexp=new ImportExport();
        ArrayList<Adolescent> guestsTest = impexp.importAdolescents("guests.csv"); //TODO Enlever le gender d'Adolescent pour ne garder que le critère ?

        // for(Adolescent a: guestsTest){
        //     System.out.println(a);
        //     System.out.println(a.getCriteria());
        // }
        // ArrayList<Adolescent> hostsTest = impexp.importAdolescents("hosts.csv");
        // for(Adolescent a: hostsTest){
        //     System.out.println(a);
        //     System.out.println(a.getCriteria());
        // }
        // ArrayList<Pair> pairs=new ArrayList<>();
        // // for(int cpt=0; cpt<pairs.size(); cpt++){
        // //     pairs.add(new Pair(guestsTest.get(cpt), hostsTest.get(cpt)));
        // // }
        // Pairing pairing=new Pairing(LocalDate.now(), "test1", "tes2", pairs);
        // impexp.exportPairing(pairing);
        // HashMap<Criterion,String> def = ImportExport.importDefaultValues();
        // System.out.println(def);
        // for (Criterion c: def.keySet()) {
            // System.out.println(def.get(c));
        // }
    }

    public static String getPath() {
        return PATH;
    }

}
