package main.exceptions;

public class MatriceException extends Exception {
    public MatriceException(){
        super();
    }

    public MatriceException(String message){
        super(message);
    }
}
