package main.exceptions;

public class ExceptionCritereGender extends Exception {
    public ExceptionCritereGender(){
        super();
    }

    public ExceptionCritereGender(String message){
        super(message);
    }
}

