package main.exceptions;

public class ExceptionCritere extends Exception {
    public ExceptionCritere(){
        super();
    }
    public ExceptionCritere(String message){
        super(message);
    }
}
