package main.exceptions;

public class ExceptionCritereBoolean extends Exception {
    public ExceptionCritereBoolean(){
        super();
    }

    public ExceptionCritereBoolean(String message){
        super(message);
    }
}

