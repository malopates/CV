package main.exceptions;

public class InvalidStructureException extends Exception{
    public InvalidStructureException(){
        super();
    }

    public InvalidStructureException(String message){
        super(message);
    }
}
