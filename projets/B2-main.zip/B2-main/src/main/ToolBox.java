package main;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 * Fournit des utilitaires pour gérer les critères et les calculs pour  l'échange linguistique.
 * @author Louis Huard
 * @author Malori Alvarez
 * @author Ulysse Petillon
 * @version 1.0
 * @since 2025-04-29
 */
public class ToolBox {

    //
    // Tableau des poids associés au respect ou non des critères pour le calcul des coûts.
    // Structure :
    // 
    //   Ligne 0 : Coût initial, cout du rédhibitoire.
    //   Ligne 1 : Gestion du genre (aucun satisfait, hôte satisfait, invité satisfait).
    //   Ligne 2 : Gestion de l'âge (différence d'âge à vérifier, non satisfait, satisfait).
    //   Ligne 3 : Réduction du coût par hobby en commun.
    //   Ligne 4 : Réduction du coût par historique
     
    public static double[][] poidsCritères = new double[][]{{5.0, 5.0}, {0.0, -1.0}, {18.0, 0.0, -1.0}, {-0.5}, {-1.0}};

 
    public static double baseValue=5.0;
    public static double ageDiff=18.0;


    /**
     * Vérifie si une chaîne est présente dans une liste de chaînes, sans distinction de casse.
     *
     * @param entry La chaîne à vérifier.
     * @param args La liste de chaînes à comparer.
     * @return true si la chaîne est présente dans la liste, false sinon.
     */
    public static boolean isAmong(String entry, String... args) {
        for (String tested : args) {
            if (tested.equalsIgnoreCase(entry)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Convertit une chaîne ("yes" ou "no") en valeur booléenne.
     * Retourne null si la chaîne n'est ni "yes" ni "no".
     *
     * @param value La chaîne à convertir.
     * @return true si la chaîne est "yes", false si elle est "no", null sinon.
     */
    public static Boolean stringToBoolean(String value) {
        Boolean resultat = null;
        if (ToolBox.isAmong(value, "yes", "no")) {
            if (value.equals("yes")) {
                resultat = Boolean.valueOf("true");
            } else {
                resultat = Boolean.valueOf("false");
            }
        }
        return resultat;
    }

    /**
     * Vérifie si l'écart entre deux dates est inférieur ou égal à une limite donnée (en mois).
     *
     * @param d1 La première date.
     * @param d2 La seconde date.
     * @param limit La limite maximale de l'écart en mois.
     * @return true si l'écart entre les dates est inférieur ou égal à la limite, false sinon.
     */
    public static Boolean dateRange(LocalDate d1, LocalDate d2, long limit) {
        long dateDiff = Math.abs(ChronoUnit.MONTHS.between(d1, d2));
        return dateDiff <= limit;
    }


}