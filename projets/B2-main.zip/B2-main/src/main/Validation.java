package main;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import main.enums.Criterion;
import main.exceptions.InvalidStructureException;

public class Validation {
    
    public static boolean checkFile(String filePath, int nbColumn, ArrayList<String> validColsNames) throws FileNotFoundException, InvalidStructureException{
        File file=new File(filePath);

        if (!(file.exists())){throw new FileNotFoundException();}

        Scanner scan=new Scanner(file);
        
        String[] header=scan.nextLine().split(""+ImportExport.CSVDELIMITER);

        scan.close();

        if(header.length!=nbColumn){
            if(header.length<nbColumn){
                throw new InvalidStructureException("Pas assez de colonnes dans le fichier : "+header.length+" à la place de "+nbColumn);
            }else{
                throw new InvalidStructureException("Trop de colonnes dans le fichier : "+header.length+" à la place de "+nbColumn);
            }
        }else{
            if(validColsNames!=null){
                for(String column : header){
                    if(!(validColsNames.contains(column))){
                        throw new InvalidStructureException("Colonne faussée : "+column);
                    }                
                }
            }
        }
        return true;
    }

    public static boolean checkFile(String filePath, int nbColumn, ArrayList<String> validColsNames, int nbLines) throws FileNotFoundException, InvalidStructureException{
        Validation.checkFile(filePath, nbColumn, validColsNames);

        int cptLignes=0;
        Scanner scan=new Scanner(new File(filePath));
        while (scan.hasNextLine()) {
            cptLignes++;
        }
        scan.close();
        if(cptLignes!=nbLines){
            if(cptLignes<nbLines){
                throw new InvalidStructureException("Pas assez de lignes : "+cptLignes+" à la place de "+nbLines);
            }else{
                throw new InvalidStructureException("Trop de lignes : "+cptLignes+" à la place de "+nbLines);
            }
        }

        return true;
    }

    public static boolean checkFileCriterionWeight(String filePath, int nbColumn, ArrayList<String> validColsNames, int nbLines) throws FileNotFoundException, InvalidStructureException{
        Validation.checkFile(filePath, nbColumn, validColsNames, nbLines);

        Scanner scan=new Scanner(new File(filePath));
        int idxLine=0;
        if(scan.hasNextLine()){//A vérifier quand même
            scan.nextLine();//Permet d'éviter le HEADER
            idxLine+=1;

        }
        while (scan.hasNextLine()) {
            String ligne[]=scan.nextLine().split(ImportExport.CSVDELIMITER);
            try{
                Criterion.valueOf(ligne[0]);
                for(String cell : Arrays.copyOfRange(ligne,1,ligne.length)){
                    Double.valueOf(cell);
                }
                // Double.valueOf(ligne[1]);
                // Double.valueOf(ligne[2]);
                // Double.valueOf(ligne[3]);
            }catch (NumberFormatException e){
                throw new InvalidStructureException("Un des poids est mal renseigné à la ligne : "+idxLine);
            }catch (IllegalArgumentException e){
                throw new InvalidStructureException("Un critère est mal écrit à la ligne : "+idxLine);
            }catch (NullPointerException np){
                throw new InvalidStructureException("Une case est vide à la ligne : "+idxLine);
            }finally{
                scan.close();
            }
        idxLine++;
        }
        scan.close();
        return true;
    }
    //Ancien Validation
    //     public static boolean checkFile(String filePath, int nbColumn, ArrayList<String> validColsNames, int nbLines) throws FileNotFoundException, InvalidStructureException{ // public pour les tests
    //     File file=new File(filePath);

    //     if (!(file.exists())){throw new FileNotFoundException();}
        
    //     Scanner scan=new Scanner(file);
    //     String[] header=scan.nextLine().split(""+ImportExport.CSVDELIMITER);
    //     int cptLignes=1;
    //     while (scan.hasNextLine()) {
    //         cptLignes++;
    //     }
    //     Validation.checkCols(header, nbColumn, validColsNames);
    //     Validation.checkLines(nbLines, cptLignes);
    //     scan.close();
    //     //Toutes les données sont des string => Pas besoin de vérifier car scan.next return un String        
    //     return true;    
    // }

    // public static void checkCols(String[] header, int nbColumn, ArrayList<String> validColsNames) throws InvalidStructureException{
    //     if(header.length!=nbColumn){
    //         if(header.length<nbColumn){
    //             throw new InvalidStructureException("Pas assez de colonnes dans le fichier : "+header.length+" à la place de "+nbColumn);
    //         }else{
    //             throw new InvalidStructureException("Trop de colonnes dans le fichier : "+header.length+" à la place de "+nbColumn);
    //         }
    //     }else{
    //         if(validColsNames!=null){
    //             for(String column : header){
    //                 if(!(validColsNames.contains(column))){
    //                     throw new InvalidStructureException("Colonne faussée : "+column);
    //                 }                
    //             }
    //         }
    //     }
    // }

    // public static void checkLines(int nbLines, int cptLignes) throws InvalidStructureException{
    //     if(nbLines>0){
    //         if(cptLignes!=nbLines){
    //             if(cptLignes<nbLines){
    //                 throw new InvalidStructureException("Pas assez de lignes : "+cptLignes+" à la place de "+nbLines);
    //             }else{
    //                 throw new InvalidStructureException("Trop de lignes : "+cptLignes+" à la place de "+nbLines);
    //             }
    //         }
    //     }
    // }


}

