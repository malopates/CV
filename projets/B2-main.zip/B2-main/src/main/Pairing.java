package main;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;

public class Pairing implements Serializable{
    private LocalDate pairingDate;
    private String guestCountry;
    private String hostCountry; //Utiliser l'énumération ici ?
    private ArrayList<Pair> pairs;
    
    public Pairing(LocalDate pariringDate, String guestCountry, String hostCountry, ArrayList<Pair> pairs){
        this.pairingDate=pariringDate;
        this.guestCountry=guestCountry;
        this.hostCountry=hostCountry;
        this.pairs=pairs;
    }
    
public String getGuestCountry() {
    return guestCountry;
}
public String getHostCountry() {
    return hostCountry;
}
public LocalDate getPairingDate() {
    return pairingDate;
}
public ArrayList<Pair> getPairs() {
    return pairs;
}

public int getNbLigne(){
    return this.pairs.size();
}
public String getFileName(){
    return this.guestCountry+"-"+this.hostCountry+"-"+this.pairingDate;
}

public String toString(){
    StringBuilder sb=new StringBuilder();
    sb.append("Date : "+pairingDate+"\nGuest : "+guestCountry+"\nHost : "+hostCountry);
    for(Pair p: this.pairs){
        sb.append(p+"\n");
    }
    return sb.toString();
}

@Override
public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((pairingDate == null) ? 0 : pairingDate.hashCode());
    result = prime * result + ((guestCountry == null) ? 0 : guestCountry.hashCode());
    result = prime * result + ((hostCountry == null) ? 0 : hostCountry.hashCode());
    result = prime * result + ((pairs == null) ? 0 : pairs.hashCode());
    return result;
}

@Override
public boolean equals(Object obj) {
    if (this == obj)
        return true;
    if (obj == null)
        return false;
    if (getClass() != obj.getClass())
        return false;
    Pairing other = (Pairing) obj;
    if (pairingDate == null) {
        if (other.pairingDate != null)
            return false;
    } else if (!pairingDate.equals(other.pairingDate))
        return false;
    if (guestCountry == null) {
        if (other.guestCountry != null)
            return false;
    } else if (!guestCountry.equals(other.guestCountry))
        return false;
    if (hostCountry == null) {
        if (other.hostCountry != null)
            return false;
    } else if (!hostCountry.equals(other.hostCountry))
        return false;
    if (pairs == null) {
        if (other.pairs != null)
            return false;
    } else if (!pairs.equals(other.pairs))
        return false;
    return true;
}



}
