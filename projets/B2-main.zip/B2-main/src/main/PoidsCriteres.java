package main;

import java.io.File;
import java.io.FileNotFoundException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Scanner;

import main.exceptions.InvalidStructureException;

public class PoidsCriteres {
    //Constantes
    private static final ArrayList<String> KEYSET=new ArrayList<>();
    static{
        KEYSET.add("Genre");
        KEYSET.add("Age");
        KEYSET.add("Hobbies");
        KEYSET.add("Allergy");
        KEYSET.add("Food");
        KEYSET.add("History");
    }
    private static final int NBCOLUMNCSV=4;
    private static final String SAVEPATH=ImportExport.getPath()+"weight.csv";
    // private static final ArrayList<String> VALIDCOLS= (ArrayList<String>) Arrays.asList(new String[]{"Critere","Poids neg","Poids neutr","Poids pos"});
    private static final ArrayList<String> VALIDCOLS;

    static {
        ArrayList<String> tmp = new ArrayList<>();
        tmp.add("Critere");
        tmp.add("Poids neg");
        tmp.add("Poids neutr");
        tmp.add("Poids pos");

        VALIDCOLS = new ArrayList<>(tmp);
    }

    private HashMap<String, ArrayList<Integer>> poids;
    //Description de la structure :
    // A chaque critère, on associe un


    // private PoidsCriteres(HashMap<String, ArrayList<Integer>> poids){
    //     this.poids=poids;
    // }

    // public PoidsCriteres getPoidsCriteres(){
    //     HashMap<String, ArrayList<Integer>> poids;
    //     try {
    //         poids=getPoids();
    //     } catch (FileNotFoundException ex) {
    //         System.out.println("Pas de fichier de configuration détecté.\nRemplissage manuel : ");
    //         poids=askPoids();
    //     }

    //     return new PoidsCriteres(poids);         

    // }

    // private HashMap<String, ArrayList<Integer>> askPoids(){
    //     for(String crit: PoidsCriteres.KEYSET){

    //     }
        
    // }
    private HashMap<String, ArrayList<Integer>> getPoids() throws FileNotFoundException{
        
        try{
            System.out.println(SAVEPATH);
            Validation.checkFileCriterionWeight(SAVEPATH,NBCOLUMNCSV,VALIDCOLS,PoidsCriteres.KEYSET.size());
            File predef=new File(SAVEPATH);
            Scanner scan=new Scanner(predef);
            HashMap<String, ArrayList<Integer>> poids=new HashMap<>();
            String ligne="";
            String[] ligneSep=null;
            ArrayList<Integer> valeurs=new ArrayList<>();
            while (scan.hasNextLine()) {
                ligne=scan.next();
                ligneSep=ligne.split(ImportExport.CSVDELIMITER);
                for(int cpt=1; cpt<ligneSep.length; cpt++){
                    valeurs.add(Integer.valueOf(ligneSep[cpt]));
                }
                poids.put(ligne, valeurs);
            }
            scan.close();
            return poids;        
        }catch(InvalidStructureException ex){
            System.out.println("M");
            throw new FileNotFoundException();
        }
    }



    public static void main(String[] args) {
        try {
        HashMap<String,ArrayList<Integer>> poids = new PoidsCriteres().getPoids();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}