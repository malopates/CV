package main.enums;

import java.util.ArrayList;

/**
 * Représente les critères utilisés pour l'échange linguistique entre adolescents.
 * Chaque critère est associé à un type, indiquant s'il s'agit d'une préférence booléenne (B) ou textuelle (T).
 *
 * @author Louis Huard
 * @author Malori Alvarez
 * @author Ulysse Petillon
 * @version 1.0
 * @since 2025-04-29
 */
public enum Criterion {
    /**
     * Indique si l'invité a une allergie aux animaux (booléen).
     */
    GUEST_ANIMAL_ALLERGY('B'),
    
    /**
     * Indique si l'hôte possède un animal (booléen).
     */
    HOST_HAS_ANIMAL('B'),
    
    /**
     * Représente les préférences alimentaires de l'invité (textuel).
     */
    GUEST_FOOD_CONSTRAINT('T'),
    
    /**
     * Représente les préférences alimentaires de l'hôte (textuel).
     */
    HOST_FOOD('T'),
    
    /**
     * Représente les hobbies de l'adolescent (textuel).
     */
    HOBBIES('T'),
    
    /**
     * Représente le genre de l'adolescent (textuel).
     */
    GENDER('T'),
    
    /**
     * Représente la préférence de genre pour le pair (textuel).
     */
    PAIR_GENDER('T'),
    
    /**
     * Représente l'historique des échanges de l'adolescent (textuel).
     */
    HISTORY('T');

    /**
     * Le type du critère, où 'B' indique un booléen et 'T' un textuel.
     */
    private char TYPE;

    /**
     * Construit un critère avec son type associé.
     *
     * @param TYPE Le type du critère ('B' pour booléen, 'T' pour textuel).
     */
    Criterion(char TYPE) {
        this.TYPE = TYPE;
    }

    /**
     * Retourne le type du critère.
     *
     * @return Le type du critère ('B' pour booléen, 'T' pour textuel).
     */
    public char getTYPE() {
        return TYPE;
    }

    public static ArrayList<String> getCriteriaList(){
        ArrayList<String> criteriaList=new ArrayList<>();
        for(Criterion c : Criterion.values()){
            criteriaList.add(c.name());
        }
        return criteriaList;
    }
}