package main.enums;

import java.util.ArrayList;

public enum CSVColumns {
    FORENAME,NAME,COUNTRY,BIRTH_DATE
    // ,GUEST_ANIMAL_ALLERGY,HOST_HAS_ANIMAL,GUEST_FOOD_CONSTRAINT,HOST_FOOD,HOBBIES,GENDER,PAIR_GENDER,HISTORY
    ;

    public static ArrayList<String> getColNames(){
        ArrayList<String> colNames=new ArrayList<>();
        for(CSVColumns c : CSVColumns.values()){
            colNames.add(c.name());
        }
        return colNames;
    }

    public static ArrayList<String> getColumnsPreset(){
        ArrayList<String> res=CSVColumns.getColNames();
        res.addAll(Criterion.getCriteriaList());
        return res;
    }

}
