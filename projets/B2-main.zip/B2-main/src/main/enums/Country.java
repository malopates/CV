package main.enums;

import java.util.ArrayList;

public enum Country {

    FR("FRANCE"),ES("SPAIN"),IT("ITALY"),GE("GERMANY");

    private final String LONGNAME;

    private Country(String LONGNAME){
        this.LONGNAME=LONGNAME;
    }

    public String getLONGNAME() {
        return LONGNAME;
    }

    public static ArrayList<String> getCountryList(){
        ArrayList<String> countryList=new ArrayList<>();
        for(Country c : Country.values()){
            countryList.add(c.LONGNAME);
        }
        return countryList;
    }
}
