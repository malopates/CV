package main;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import main.enums.Country;
import main.enums.Criterion;
/**
 * Représente l'identité d'un adolescent, donc un son nom, prénom, Genre... Et ses critères dans le contexte d'un échange linguistique avec un autre adolescent pour former une pair hôte-invité.
 * 
 * @author Louis Huard
 * @author Malori Alvarez
 * @author Ulysse Petillon
 * 
 * @version 1.0
 * 
 * @since 2025-04-09
 * 
 */
public class Adolescent implements Comparable<Adolescent>, Serializable{
    /**
     * Le nom de l'adolescent.
     */
    private String lastname;

    /**
     * Le prénom de l'adolescent.
     */
    private String forename;

    /**
     * Le genre de l'adolescent.
     */
    private String gender; //TODO A VIRER

    /**
     * La date de naissance de l'adolescent.
     */
    private final String BIRTHDATE;
    private final transient DateTimeFormatter dtf = DateTimeFormatter.ISO_LOCAL_DATE;

    /**
     * Le pays de naissance de l'adolescent.
     */
    private final String BIRTHCOUNTRY;

    /**
     * Les critères de l'adolescent dans le contexte d'échange linguistique.
     */
    private HashMap<Criterion, String> criteria;

    /**
     * L'historique de l'adolescent, la dernière paire hôte-visiteur l'incluant.
     */
    private transient Adolescent lastPaired; //TODO vérifier la sérialisation

    /**
     * Crée un adolescent avec ses informations personnelles et ses critères. 
     * 
     * @param lastname Le nom de l'dolescent.
     * @param forename Le prénom de l'adolescent.
     * @param gender Le genre de l'adolescent.
     * @param BIRTHDATE La date de naissance de l'adolescent.
     * @param BIRTHCOUNTRY Le pays de naissance de l'adolescent.
     * @param criteria Les critères de l'adolescent pour l'échange linguistique.
     */
    public Adolescent(String lastname, String forename, String gender, String BIRTHDATE, String BIRTHCOUNTRY, HashMap<Criterion, String> criteria){
        this.lastname=lastname;
        this.forename=forename;
        this.gender=gender;
        this.BIRTHDATE=BIRTHDATE;
        this.BIRTHCOUNTRY=BIRTHCOUNTRY;
        this.criteria=criteria;
        this.lastPaired=null;
    }

    //Accesseurs
    
    /**
     * Retourne le nom de l'adolescent.
     *
     * @return Le nom de l'adolescent.
     */
    public String getLastname() {
        return lastname;
    }

    /**
     * Retourne le prénom de l'adolescent.
     *
     * @return Le prénom de l'adolescent.
     */
    public String getForename() {
        return forename;
    }

    /**
     * Retourne le genre de l'adolescent.
     *
     * @return Le genre de l'adolescent.
     */
    public String getGender() {
        return gender;
    }

    /**
     * Retourne la date de naissance de l'adolescent.
     *
     * @return La date de naissance de l'adolescent.
     */
    public String getBIRTHDATE() {
        return BIRTHDATE;
    }

    /**
     * Retourne le pays de naissance de l'adolescent.
     *
     * @return Le pays de naissance de l'adolescent.
     */
    public String getBIRTHCOUNTRY() {
        return BIRTHCOUNTRY;
    }

    /**
     * Retourne les critères de l'adolescent pour l'échange linguistique.
     *
     * @return Une map contenant les critères et leurs valeurs associées.
     */
    public HashMap<Criterion, String> getCriteria() {
        return criteria;
    }

    // Mutateurs

    /**
     * Modifie le nom de l'adolescent.
     *
     * @param lastname Le nouveau nom de l'adolescent.
     */
    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    /**
     * Modifie le prénom de l'adolescent.
     *
     * @param forename Le nouveau prénom de l'adolescent.
     */
    public void setForename(String forename) {
        this.forename = forename;
    }

    /**
     * Modifie le genre de l'adolescent.
     *
     * @param gender Le nouveau genre de l'adolescent.
     */
    public void setGender(String gender) {
        this.gender = gender;
    }

    /**
     * Modifie les critères de l'adolescent pour l'échange linguistique.
     *
     * @param criteria La nouvelle map des critères et leurs valeurs associées.
     */
    public void setCriteria(HashMap<Criterion, String> criteria) {
        this.criteria = criteria;
    }

    /**
     * Modifie l'historique de l'adolescent en enregistrant le dernier adolescent avec lequel il a été pairé.
     *
     * @param lastPaired Le dernier adolescent pairé dans un échange.
     */
    public void setLastPaired(Adolescent lastPaired) {
        this.lastPaired = lastPaired;
    }


    public String getHistory(){
        return this.criteria.get(Criterion.HISTORY);
    }
    public Adolescent getLastPaired(){
        return this.lastPaired;
    }
    


    //Equals (Généré, à vérifier/retoucher)

    /**
     *  Vérifie l'égalité entre deux adolescent.
     * 
     * @param obj L'adolescent comparé.
     * @return True si les deux adolescent sont égaux, False sinon.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (this.getClass() != obj.getClass())
            return false;
        Adolescent other = (Adolescent) obj;
        if (this.lastname == null) {
            if (other.lastname != null)
                return false;
        } else if (!lastname.equals(other.lastname))
            return false;
        if (this.forename == null) {
            if (other.forename != null)
                return false;
        } else if (!forename.equals(other.forename))
            return false;
        if (this.gender == null) {
            if (other.gender != null)
                return false;
        } else if (!gender.equals(other.gender))
            return false;
        if (this.BIRTHDATE == null) {
            if (other.BIRTHDATE != null)
                return false;
        } else if (!BIRTHDATE.equals(other.BIRTHDATE))
            return false;
        if (this.BIRTHCOUNTRY == null) {
            if (other.BIRTHCOUNTRY != null)
                return false;
        } else if (!BIRTHCOUNTRY.equals(other.BIRTHCOUNTRY))
            return false;
        if (this.criteria == null) {
            if (other.criteria != null)
                return false;
        } else if (!criteria.equals(other.criteria))
            return false;
        // if (this.lastPaired == null) { //Pas utilisable car boucle infini de equals
        //     if (other.lastPaired != null)
        //             return false;
        // } else if (!this.lastPaired.equals(other.lastPaired))
        //     return false;
        return true;
    }

    public int compareTo(Adolescent other){
        return this.lastname.compareTo(other.lastname);
    }

    //Méthodes

    /**
     * Vérifie la cohérence d'un adolescent, e.g si les valeurs entré correspondent à celles attendues ET si il n'y a pas de problèmes, par exemple que l'adolescent souhaite un chien chez l'hôte alors qu'il y est alergique.
     * 
     * @return True si l'adolescent est coherent avec les réponses attendues, False sinon.
     */
    public boolean isCoherent(){ 
        boolean coherency=false;

        // if (logicalCriteria()){
            if(!(this.hasAnimal()&&this.isAllergic())){
                if(Country.getCountryList().contains(this.BIRTHCOUNTRY)){//TODO Faire une varibale
                    if(this.gender.equalsIgnoreCase(this.criteria.get(Criterion.GENDER))){
                        // if(!((this.criteria.get(Criterion.HISTORY).equals(""))&&(this.lastPaired!=null))){
                            coherency=true;
                        // }else{System.out.println("History mal rempli");}
                    }else{
                        System.out.print(this.toStringName()+" ");
                        System.out.println("Gender ("+this.gender+") et GENDER ("+this.criteria.get(Criterion.GENDER)+") incohérents");}
                }else {System.out.println("Mauvais pays : "+BIRTHCOUNTRY);}
            }else{System.out.println("Allergie incohérente");}
        // }
        return coherency;
    }//TODO : Ajouter un système d'exception CoherencyException.java

    //TO DO : Mettre ces 3 là en private
    /**
     * Vérifie si un hôte possède ou non un animal chez lui ou si un invité souhaite que l'hôte en possède un ou non.
     * 
     * @return True si l'hôte possède un animal ou si l'invité souhaite que l'hôte en possède un, False sinon.
     */
    public boolean hasAnimal(){
        return ToolBox.stringToBoolean(this.getCriteria().get(Criterion.HOST_HAS_ANIMAL));
    }

    /**
     * Vérifie si un hôte peut gérer un invité avec des allergies aux chiens ou si un invité souahite un hôte pouvant le gérer.  
     * @return True si l'hôte peut ou si l'invité le souhaite, False sinon.
     */
    public boolean isAllergic(){
        return ToolBox.stringToBoolean(this.getCriteria().get(Criterion.GUEST_ANIMAL_ALLERGY));
    }

    // /**
    // // Vérifie la cohérence d'un adolescent, e.g si toutes les valeurs entrées soit cohérent selon le type (boolean) ou cohérent selon le genre de valeurs attendues , quand c'est possible.
    //  * 
    //  * @return True si l'adolescent est cohérent, False sinon
    //  */
    // public boolean logicalCriteria(){//Vérifie la cohérence de la valeur : 1) "yes" ou "no" pour les booléens 2) un des valeurs connues pour les critères à réponses limitées
    //     //private 
    //     boolean logical=true;
    //     String value;
    //     for (Criterion c: this.criteria.keySet()){
    //         value=criteria.get(c);
    //         try{
    //             this.logicalCriterion(c, value);
    //         }
    //         catch(ExceptionCritere e){
    //             System.out.println(e.getMessage());
    //             logical=false; //Uniquement pour l'intégrité des tests 
    //             if(c.getTYPE()=='t'){
    //                 return false;
    //             }else if(c==Criterion.GENDER){
    //                 this.criteria.put(c,"other");
    //             }else{
    //                 this.criteria.put(c, "");//Choix : Nullifier le critère, le rend équivalent à non rempli !
    //             }
    //         }
    //     }
    //     return logical; //True si c'est bon ou corrigé / False si c'est impossible à corriger ET DONC l'adolescent est viré à l'import
    //     //TODO : A deplacer lors de l'écriture de l'import
    //     //TODO : Exception critiques
    // }


    // //Ecriture de logicalCriterion avec des Exception
    // public boolean logicalCriterion(Criterion c, String value) throws ExceptionCritere{
    //     boolean logical=true;
    //     if (c.getTYPE()=='B'){
    //         if(!(ToolBox.isAmong(value,"yes","no"))){
    //             throw new ExceptionCritere("Booléen incorrect : Adolescent à retirer");
    //         }
        
    //     } else if (c==Criterion.GENDER){
    //         if(!(ToolBox.isAmong(value, "male","female","other"))){
    //             throw new ExceptionCritere("Critère GENDER incorrect");
    //         }
        
    //     }else if (c==Criterion.PAIR_GENDER){ //Null empêche de fusionner avec la partie supérieure
    //         if(!(ToolBox.isAmong(value, "male","female","other",""))){
    //             throw new ExceptionCritere("Critère PAIR GENDER incorrect")
    //             ;}
        
    //     }else if (c==Criterion.HISTORY){
    //         if(!(ToolBox.isAmong(value, "other","same",""))){
    //             throw new ExceptionCritere("Critère HISTORY incorrect");
    //         }
        
    //     }else if((c==Criterion.GUEST_FOOD)||(c==Criterion.HOST_FOOD)){
    //         if(!(ToolBox.isAmong(value, "nonuts","vegetarian","nonuts,vegetarians","vegetarian,nonuts",""))){ //TODO split
    //             throw new ExceptionCritere("Critère GUEST_FOOD ou HOST_FOOD incorrect");
    //         }
    //     }
    //     return logical;
    // }




    /**
     * Sert à calculer le score de compatibilité d'un pair hôte-invité.
     * 
     * @param host L'adolescent hôte.
     * @param guest L'adolescent invité.
     * @return Le score attribuer à la pair en fonction des critères de chacuns, sous forme de double.
     */
    public double compatibilityScore(Adolescent host){ //Utilisation de static pour améliorer la compréhension et permettre un caclcul qu'on parte de l'host ou du guest
        double cS=ToolBox.poidsCritères[0][0];
        double[][] matriceCout=ToolBox.poidsCritères;
        if((this.isCoherent())&&(host.isCoherent())){ 
            // System.out.println("Valeur de départ"+cS);
            //Calcul genre
            cS+=this.genderCriteria(matriceCout[1],host);
            // System.out.println("Genre :"+this.genderCriteria(matriceCout[1],host));
            //Calcul age
            cS+=this.ageCriteria(matriceCout[2], host);
            // System.out.println("Age :"+this.ageCriteria(matriceCout[2], host));
            //Calcul hobby
            cS+=this.hobbyCriteria(matriceCout[3], host);
            // System.out.println("Hobby :"+this.hobbyCriteria(matriceCout[3], host));
            //Calcul animal
            cS+=this.animalCriteria(host);
            // System.out.println("Animal :"+this.animalCriteria(host));
            //Calcul nourriture
            cS+=this.foodCriteria(host);
            // System.out.println("Nourriture :"+this.foodCriteria(host));
            //Calcul history
            cS+=this.historyCriteria(host);
            // System.out.println("History : "+this.historyCriteria(matriceCout[4], host));
        }else{ 
            cS=((ToolBox.poidsCritères[0][1])*100);
        }
        return cS;
    }

    public double genderCriteria(double[] genderCost, Adolescent host){ //private
        double gS=genderCost[0];

        String[] guestWishes=this.getGenderCriteria(); //0 est le GENDER, 1 est le PAIR_GENDER
        String[] hostWishes=host.getGenderCriteria();

        if((guestWishes[1].equals(""))||(guestWishes[1].equals(hostWishes[0]))){//Si le guest n'a pas de préférence ou qu'elle est remplie (on assume une normalisation des entrées)
            gS+=genderCost[1];
        }
        if((hostWishes[1].equals(""))||(hostWishes[1].equals(guestWishes[0]))){ //Si l'hôte n'a pas de  préférence ou qu'elle est remplie
            gS+=genderCost[1];
        }
        
        return gS;
    }

    // Récupère le genre et le genre souhaité d'un adolescent.
    public String[] getGenderCriteria(){ //0 le genre du concerné, 1 le genre souhaité par le concerné //private
        String[] genderCriteria=new String[2];
        genderCriteria[0]=this.getCriteria().get(Criterion.GENDER);
        genderCriteria[1]=this.getCriteria().get(Criterion.PAIR_GENDER);
        return genderCriteria;
    }

    // Récupère l'age d'un adolescent.
    public  double ageCriteria(double[] ageCost, Adolescent host){ //private
        double aS;
        long limit=(long) ageCost[0];
        LocalDate dateHost=LocalDate.parse(host.BIRTHDATE,dtf);
        LocalDate dateGuest=LocalDate.parse(this.BIRTHDATE,dtf);
        if(ToolBox.dateRange(dateHost, dateGuest, limit)){
            aS=ageCost[2];
        }else{
            aS=ageCost[1];
        }
        return aS;
    }

    // Récupère les hobbys d'un adolescent
    public double hobbyCriteria(double[] hobbyCost, Adolescent host){ //private
        double hS=0.0;
        //
        
        List<String> guestHobby= Arrays.asList(this.criteria.get(Criterion.HOBBIES).replaceAll(" ", "").split(","));
        List<String> hostHobby= Arrays.asList(host.criteria.get(Criterion.HOBBIES).replaceAll(" ", "").split(","));
        // System.out.println(guestHobby);
        // System.out.println(hostHobby);


        // int commonHobbys=0;
        
        for(String hobby: guestHobby){ //Pose le problème de la casse => void convertToLowerCase(String[] tab) ?
            if (hostHobby.contains(hobby)){
                // System.out.println(hobby);
                hS+=hobbyCost[0];
                // System.out.println(hS);
                // commonHobbys++;   
            }
        }
 
        if(((this.isFrench())||(host.isFrench()))&&(hS==0.0)){
            hS+=100;
        }
        // hS+=this.frenchConnection(host, hS);
        
        return hS;
    }

    //NATIONALITE

    //Fonction pour bien séparer le critère de nationalité
    public double frenchConnection(Adolescent host, double hS){
        double frenchMalus=0.0;
        if(((this.isFrench())||(host.isFrench()))&&(hS==0.0)){
            frenchMalus=ToolBox.poidsCritères[0][1];
        }
        return frenchMalus;

    }
    // True si un adolescent est français, False sinon.
    public boolean isFrench(){ //private
        return this.getBIRTHCOUNTRY().equals("FR");
    }
 
    //Critères rédhibitoires

    public double animalCriteria(Adolescent host){
        double aS=0.0;
        
        boolean guestAllergic=ToolBox.stringToBoolean(this.criteria.get(Criterion.GUEST_ANIMAL_ALLERGY));
        boolean hostHasDog=ToolBox.stringToBoolean(host.criteria.get(Criterion.HOST_HAS_ANIMAL));

        if(guestAllergic&&hostHasDog){
            aS+=ToolBox.poidsCritères[0][1];
        }

        return aS;
    }

    public double foodCriteria(Adolescent host){
        double fS=0.0;
        // System.out.println("Guest food : "+this.criteria.get(Criterion.GUEST_FOOD_CONSTRAINT));
        // System.out.println("Guest food");
        List<String> guestFood= Arrays.asList(this.criteria.get(Criterion.GUEST_FOOD_CONSTRAINT).replaceAll(" ", "").split(","));

        List<String> hostFood= Arrays.asList(host.criteria.get(Criterion.HOST_FOOD).replaceAll(" ", "").split(","));

        for (String guestDiet: guestFood){
            if((!(guestDiet.equals("")))&&(!(hostFood.contains(guestDiet)))){
                fS+=ToolBox.poidsCritères[0][1];
            }
        }
        return fS;
    }

    public double historyCriteria(Adolescent host){
        double hisS=0.0;
        String guestHistory=this.getHistory();
        String hostHistory=host.getHistory();
        // System.out.println("guestHistory = "+guestHistory);
        // System.out.println("hostHistory = "+hostHistory);


        Adolescent guestLastPaired=this.getLastPaired();
        Adolescent hostLastPaired=host.getLastPaired();

        double coutRedhib=ToolBox.poidsCritères[0][1];
        double coutSatisfait=ToolBox.poidsCritères[4][0];

        //On a déjà éliminé ceux qui veulent tous les deux être avec l'ancien
        //On a aussi aucun adolescent qui n'a pas de lastPaired avec un history non null

        //Si un history est null, on considère alors que la personne est satisfaite

        //Deux cas principaux : ils sont lastPaired tous les deux
        if((this.hasLastPaired())&&(guestLastPaired.equals(hostLastPaired))){
            if(guestHistory.equals("other")){ //Un qui déteste l'autre est moins pire que deux qui se détestent
                hisS+=coutRedhib;
            }
            if(hostHistory.equals("other")){
                hisS+=coutRedhib;
            }
            if((ToolBox.isAmong(guestHistory,"same","")||(ToolBox.isAmong(hostHistory,"same","")))){//Pas possbile d'avoir les deux en même temps => Géré dans Main.java
                hisS+=coutSatisfait;
            }
        } else { //Si ils n'étaient pas lastPaired
            if ((this.hasLastPaired())&&(ToolBox.isAmong(guestHistory, "other",""))){
                hisS+=coutSatisfait;
            }
            if ((host.hasLastPaired())&&(ToolBox.isAmong(hostHistory,"other",""))){
                hisS+=coutSatisfait;
            }
            //On se fiche des sames => Insatisfait on touche pas
            // Rappel
            // Satisfait, on diminue le score
            // Insatisfait, on touche pas au score
            // Contrarié, on augmente le score
        }
        return hisS;
    }

    private boolean hasLastPaired(){
        return this.lastPaired!=null;
    }

    public String toStringName(){
        return this.forename+" "+this.lastname;
    }

    public String toString(){
        return this.toStringName();
    }

    public String toStringLong(){
        StringBuilder sb=new StringBuilder();
        sb.append("Adolescent : "+this.toStringName()+"\n");
        sb.append("Pays : "+this.BIRTHCOUNTRY+"\n");
        sb.append("Genre : "+this.gender+"\n");
        sb.append("");
        for(Criterion c: Criterion.values()){//this.criteria ?
            sb.append(c.name()+" : "+this.criteria.get(c)+"\n");
        }
        return sb.toString();
    }
    //

}