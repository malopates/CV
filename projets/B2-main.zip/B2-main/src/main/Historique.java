package main;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.Year;
import java.util.ArrayList;
import java.util.HashMap;

public class Historique implements Serializable{

    private static final long serialVersionUID = 3717309890257604087L;


    public static int cptID = 1;
    public final int ID;
    public HashMap<Integer, ArrayList<Pairing>> historic;
    private static String path=ImportExport.getPath();


    public Historique() {
        this.historic = new HashMap<Integer, ArrayList<Pairing>>();
        this.ID = cptID++;
    }

    public void saveHistoric(){
        try(
            // FileOutputStream fos = new FileOutputStream(path+"historique.ser");
            FileOutputStream fos = new FileOutputStream("/res/historique.ser");

            ObjectOutputStream oos = new ObjectOutputStream(fos);
            ) 
        {
            System.out.println("Historique correctement sérialisé");
            oos.writeObject(this);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static Historique loadHistoric(){
        
        InputStream is=Historique.class.getResourceAsStream("/res/historique.ser");

        if(is==null){
            return new Historique();
        }

        
        try (
            // FileInputStream fos = new FileInputStream(path+"historique.ser");

            // FileInputStream fis = new FileInputStream("/res/historique.ser");


            ObjectInputStream ois = new ObjectInputStream(is);
            )
        {
            System.out.println("Historique correctement désérialisé");
            return (Historique) ois.readObject();

        } catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }
    }

    public HashMap<Integer, ArrayList<Pairing>> getHistoric() {
        return historic;
    }

    public String toString(){
        StringBuilder sb=new StringBuilder();
        for(Integer year : this.historic.keySet()){
            sb.append("Année : "+year+"\n");
            for(Pairing p : this.historic.get(year)){
                sb.append(p+"\n");
            }
        }
        return sb.toString();
    }

    // public static void main(String[] args) {
    //     // Utilisé pour créer l'instance initial de historique.ser
    //     Historique histo=new Historique();

    //     Pair test=new Pair(160.0,new Adolescent("Bovi", "Jon", "male", "2001-03-03", "FRANCE", null), new Adolescent("Jovi", "Bon", "male", "2001-03-03", "FRANCE", null));

    //     ArrayList<Pair> testPair=new ArrayList<>();
    //     testPair.add(test);

    //     Pairing testPairing=new Pairing(LocalDate.now(), test.guest.getBIRTHCOUNTRY(), test.host.getBIRTHCOUNTRY(), testPair);

    //     ArrayList<Pairing> listPairings=new ArrayList<>();
    //     listPairings.add(testPairing);

    //     histo.getHistoric().put(testPairing.getPairingDate().getYear(), listPairings);

    //     System.out.println(histo.historic.get(LocalDate.now().getYear()));


    //     histo.saveHistoric();

    //     Historique histo2=Historique.loadHistoric();

    //     System.out.println(histo2.historic.get(LocalDate.now().getYear()));
    // }
}
